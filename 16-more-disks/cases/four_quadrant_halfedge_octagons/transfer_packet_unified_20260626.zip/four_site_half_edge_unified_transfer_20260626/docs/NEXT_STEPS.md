# Recommended next steps

1. Independently replay / audit `code/evolve_four_site_search.go` against both
   JSON result files.
2. Produce a raw per-event ledger for classes 8 and 31, including every batch,
   exact `Q(sqrt(2))` time, contacts, and post-batch state hash.
3. Generate any future video only from that ledger. Choose one explicit map
   from physical time to video time, then assert in code that first body-body
   event lands on the requested frame before encoding.
4. Keep visual layout separate from physical geometry: the drawn square must
   be the physical wall boundary, with no inset padding.
