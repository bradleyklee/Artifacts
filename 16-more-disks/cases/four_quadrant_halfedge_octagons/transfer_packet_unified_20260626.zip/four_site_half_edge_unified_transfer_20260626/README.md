# Four-site half-edge hard-octagon — unified transfer packet

## Scope

Exact fixed-orientation hard-octagon search in the square of side
`2 + 2*sqrt(2)`, with four allowed quadrant-centre sites and octagon edge
length `1/2`. Arithmetic in the search is over `Q(sqrt(2))`.

## Exact search status (source: results/REPORT.md and JSON)

- `N=2`: 16 D4 classes, all exact unlabeled returns.
- `N=3`: 32 D4 classes after the class-8 continuation:
  - 12 `RETURN`
  - 15 `UNKNOWN_CORNER`
  - 2 `COMPLEXITY_CUTOFF`
  - 3 `REJECT`

The two cap cases are:

- Class 8: `Q[-1,+1] +y; Q[+1,-1] +x; Q[+1,+1] -y`
  - continuation reaches batch 2357
  - state bits 129; position bits 129; velocity bits 85
  - 827 pair collisions
  - first 20 lex-min ternary digits:
    `0,1,2,0,0,2,0,0,0,1,0,1,0,1,2,1,2,1,1,2`
  - channel map `P0/P1->1, P0/P2->2, P1/P2->0`

- Class 31: `Q[-1,+1] -y; Q[+1,-1] +y; Q[+1,+1] +x`
  - reaches batch 2045
  - state bits 129; position bits 129; velocity bits 84
  - 712 pair collisions
  - first 20 lex-min ternary digits:
    `0,1,0,2,1,1,2,1,0,1,1,2,1,2,0,0,2,0,2,2`
  - channel map `P0/P1->2, P0/P2->1, P1/P2->0`

## What is and is not unified here

`code/` and `results/` are the exact-search record.

`render/` is separate visual work. It is not an independent verifier and is
not evidence for the search claims. In particular:

- `collision_times_per_frame.txt` is a ledger for the supplied
  `two_growth_cases_vertical_90s_geometry_fixed.zip` render.
- That ledger says the first body-body contact in that particular geometry
  render is at video frame 60 / 2.0 seconds (30 fps), despite an earlier
  intended 1-second target.
- `two_growth_cases_vertical_90s_first_pair_at_1s.zip` is a timing-targeted
  render from the same helper path, but its geometry/layout was rejected.
- Do not treat either video as a certified long exact evolution. They are
  retained only so the current visual branch is recoverable.

## Layout

- `code/` — exact Go search program.
- `results/` — complete enumeration JSON, class-8 continuation JSON, report,
  and captured console output.
- `figures/` — generated initial-condition figures.
- `render/` — latest visual materials plus collision-time ledger and caveats.
- `SHA256SUMS` — hashes for all transferred files.
