# Unified lattice collision evolver — finisher branch

One exact, fixed-orientation hard-polygon core covers `square`, `octagon`,
`dodecagon`, and `24gon`. Every model uses edge `1/2`; its cardinal width is
exactly one-half of a lattice cell. The smallest permitted container is `L=2`.

## Current supported families

- Lattice starts: choose `N` distinct L×L cell centroids and ordered unit
  cardinal velocity labels `E,W,N,S`.
- Centered starts: place two bodies in an exact prescribed face contact at the
  container centre, require an approaching cardinal velocity pair, resolve that
  face collision at time zero, then evolve.

## Exactness and degeneracies

Scalar cores are Q, Q(√2), Q(√3), and Q(√2,√3). Floats are never used to
choose a next event, test support, select a facet, or compare states.

Only `PAIR_FACE`, `WALL_FACE`, and batches of walls affecting distinct bodies
are resolved. `PAIR_CORNER`, `WALL_CORNER`, and `COUPLED_SIMULTANEOUS` are
terminal classifications. A finite `CAP` is a regular horizon survivor, never
an assertion of chaos.

## Commands

```bash
make test
make atlas-dodecagon
make atlas-24gon
make atlas-centered
```

The emitted JSON includes raw ordering, full same-time batches, exact time,
state hashes, exact pre/post states, pair-facet words, and coefficient metrics.

## Executed finisher snapshot

`RUN_STATUS.md` lists the results actually generated in this packet. The
important reconciliation is `KNOWN_DIFFERENCES.md`: under the strict
no-serialization policy, eight octagon L=2,N=2 starts are `WALL_CORNER`
terminals rather than the legacy report's continued returns.

Run the full independently checked baseline with `make verify`; run the
additional raw square/octagon ledger families with `make atlas-low`.
