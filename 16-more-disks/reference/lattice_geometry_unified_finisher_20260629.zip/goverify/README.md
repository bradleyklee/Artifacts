# Independent replay checker

`go run ./goverify --certificate certificates/centered_dodecagon_f1_EN_500.json`

This checker independently implements Q(√3), support-facet event generation,
complete same-time batch classification, and elastic face reflection for the
centered L=2 dodecagon certificate. It verifies every exact event time, batch,
facet/wall label, final state, and pair-facet word.
