# Adversarial certificate review request

This is a finite exact-billiard claim, not a request to infer chaos from a
long trajectory. Please independently review the centered dodecagon witness
only, and report a concrete mismatch if one exists.

## Target

`../certificates/centered_dodecagon_f1_EN_500.json`

Two fixed-orientation regular dodecagons of edge `1/2` sit in the square
container of half-side `2+sqrt(3)`. Facet `k` has normal angle `30k` degrees.
The seed is central face `1`, incoming velocities `(E,N)`, resolved elastically
at time zero. The certificate claim is exactly: the trajectory is regular and
unrepeated through 500 physical event batches, with 108 body-body face
contacts. No assertion of nonperiodicity or chaos is intended.

## Required checks

1. Derive the apothem `(2+sqrt(3))/4`, central starting centres, and outgoing
   velocities after the time-zero elastic reflection.
2. Recompute candidate wall and pair-support contact times in `Q(sqrt(3))`.
3. At every tied time, classify the whole batch before resolving any event.
   Do not serialize a corner or coupled batch.
4. Compare every emitted time, event class, wall/facet label, pair-facet word,
   and final exact state to the JSON certificate.
5. State whether the certificate supports only a 500-event regular survivor,
   or something stronger. Reject any stronger conclusion not logically proved.

## Included independent implementations

- `../lattice_collision/` — Python reference evolver.
- `../goverify/main.go` — independent Go replay of the centered certificate.
- `../tools/verify_transfer_parity.py` — parity checks against the transferred
  provisional targets.

A useful review result is either an independently reproduced trace or the
first exact divergence, with the full state and contact batch at that point.
