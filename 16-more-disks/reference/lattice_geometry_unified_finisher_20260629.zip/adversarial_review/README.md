# Adversarial-review packet

Run locally from the project root:

```bash
make verify
go run ./goverify --certificate certificates/centered_dodecagon_f1_EN_500.json
```

Then use `REVIEW_PROMPT.md` with a separate model or implementation. The
packet is deliberately narrow: it asks for falsification or reproduction of a
specific exact 500-event ledger, not an opinion about the trajectory.
