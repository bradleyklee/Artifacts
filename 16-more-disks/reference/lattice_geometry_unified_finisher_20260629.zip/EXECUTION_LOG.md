# Executed verification log

The following were executed in this build environment:

```text
python3 -m unittest -v tests/test_regression.py
  5 tests passed

python3 tools/verify_transfer_parity.py
  dodecagon L=2,N=2: passed
  dodecagon L=3,N=2: passed
  24-gon L=2,N=2: passed
  centered dodecagon face 1 E/N at 500: passed

go run ./goverify --certificate certificates/centered_dodecagon_f1_EN_500.json
  GO_CERTIFICATE_REPLAY=OK events=500 pair_faces=108
```

The Go checker independently regenerated every nonzero event in the centered
certificate, including exact time, complete batch, facet/wall labels,
pair-facet word, and final state.
