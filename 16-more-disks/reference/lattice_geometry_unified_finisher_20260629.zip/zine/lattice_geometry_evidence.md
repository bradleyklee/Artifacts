# Lattice collisions: where the first complications actually appear

We used one exact event engine for fixed-orientation squares, octagons,
dodecagons, and 24-gons. Every mover has edge length one-half and occupies
one-half of a lattice cell in each cardinal direction. Starts use distinct
cell centroids and unit cardinal velocities; a separate family begins from a
prescribed central face contact and resolves it at time zero.

The small atlases do not justify a general chaos claim. They do make the
threshold visible. In the 2×2 square control, every two-body run either
returns or reaches a classified corner. The two-body octagon control likewise
returns except at strict wall corners. With three octagons, regular survivors
appear before event 256 and their exact denominators grow. Dodecagon lattice
starts at the tested 2×2 and 3×3 scales still return or terminate, but an
off-cardinal central face collision produces a regular 500-event survivor.
A 24-gon already reaches tilted pair facets from cardinal starts and has
regular 100-event survivors in its 2×2 atlas.

Each terminal contact is preserved as data rather than silently serialised:
pair corners, wall corners, and coupled simultaneous batches are distinct
classes. A survivor at a declared cap is only a finite-horizon survivor.
The strongest current dodecagon record is independently replayed in Python
and Go: its 500 event batches, exact times, full facet word, and final
algebraic state agree.

**Figures.**

- `figures/centered_dodecagon_f1_EN_initial.svg` — central off-cardinal seed.
- `figures/octagon_L2_N3_first_regular_survivor_256_initial.svg` — first
  three-body octagon survivor in the shared raw ordering.
- `figures/24gon_L2_N2_first_offcardinal_survivor_100_initial.svg` — earliest
  24-gon regular survivor and tilted-facet witness.

**Caption convention.** Every figure names the model, start family, event cap,
and classification. “Chaos” is reserved for a later proof-level conclusion,
not a visual impression or a long unrepeated prefix.
