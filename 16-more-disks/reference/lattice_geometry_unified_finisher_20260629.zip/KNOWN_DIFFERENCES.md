# Reconciliation notes

## Octagon L=2, N=2: eight strict wall corners

The transferred octagon documentation reports all 16 D4 classes as returns.
Under the unified contract, eight of the 96 raw starts reach a same-body,
two-wall contact. The first is sites `[0,3]`, velocities `[E,N]`, at batch 3.

This is not asserted as a discrepancy in free flight or ordinary face
reflection. It is a **classification policy difference at the terminal
contact**: the unified engine does not serialise or automatically resolve a
wall corner. It records `WALL_CORNER`; the legacy octagon report continued
those paths to a return. The first such contact has its own certificate:
`certificates/octagon_L2_N2_first_wall_corner.json`.

Dodecagon and 24-gon transferred 2×2 atlases already placed their analogous
eight cases into a terminal simultaneous bucket. The unifier makes the
subtype visible across all shapes.
