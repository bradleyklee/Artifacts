# Transfer packet: unified lattice-geometry finisher

## What is executable and checked

- One exact Python event core for fixed-orientation squares, octagons,
  dodecagons, and 24-gons; fields Q, Q(√2), Q(√3), and Q(√2,√3).
- Full same-time-batch classification with terminal `PAIR_CORNER`,
  `WALL_CORNER`, and `COUPLED_SIMULTANEOUS`; no implicit corner serialisation.
- Full raw JSON ledgers for L=2 square and octagon controls, L=2/L=3
  dodecagon atlases, L=2 24-gon atlas, and the centered dodecagon sweep.
- Standalone certificates for the current key records.
- Python parity checks plus an independent Go replay of the centered
  dodecagon 500-event certificate.
- Vector initial-condition plates, an event-index MP4, and a conservative
  zine-ready Markdown section.

## Commands

```bash
make test
make atlas-dodecagon
make atlas-24gon
make atlas-centered
make certificates
go run ./goverify --certificate certificates/centered_dodecagon_f1_EN_500.json
python3 tools/verify_transfer_parity.py
make atlas-low
make render
```

`make verify` runs the first six of these sequentially. It can take longer
than an interactive tool timeout, so it is also safe to run the listed
commands one at a time.

## Important claim boundary

A `CAP` record means only: no return or classified terminal event was found by
that exact event horizon. It does **not** prove chaos or nonperiodicity.

## Open work deliberately left open

1. Extend the unified search beyond the listed low atlases with an explicit
   complexity-budget policy and resumable checkpoints.
2. Deep-replay the centered dodecagon E/N record to the transferred 12,000
   batches in the new core and add a second-language check for a longer prefix.
3. Add a Go verifier for a 24-gon tilted-facet certificate and generic N=3
   certificate ingestion.
4. Decide a physically justified treatment of wall and pair-corner contacts;
   do not quietly convert them into ordinary collisions.
5. Insert the generated zine section into the canonical issue source only when
   that source is available; this packet intentionally does not modify it.
