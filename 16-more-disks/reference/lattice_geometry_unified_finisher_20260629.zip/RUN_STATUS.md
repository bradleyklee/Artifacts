# Finisher status — executed evidence only

## Reproduced transfer targets

The unified exact Python core reproduces the provisional dodecagon L=2/L=3 and
24-gon L=2 atlas totals after making the old undifferentiated simultaneous
bucket explicit: all such archived cases here are `WALL_CORNER` events.

It also reproduces the centered dodecagon face 1, incoming E/N trace through
500 event batches: status `CAP`, exact time, 108 pair-facet labels, and final
position/velocity/time coefficient metrics all agree with the transferred
record. `goverify/` independently checks that certificate in Go.

## New common-ordering low atlas snapshot

| model | family | result under strict batch contract |
|---|---|---|
| square | L=2, N=2 | 48 returns, 40 pair corners, 8 wall corners |
| square | L=2, N=3 | 32 returns, 144 pair corners, 32 wall corners, 48 coupled batches |
| octagon | L=2, N=2 | 88 returns, 8 wall corners |
| octagon | L=2, N=3, cap=256 | 48 returns, 72 pair corners, 56 wall corners, 72 coupled batches, 8 regular survivors |
| dodecagon | L=2, N=2 | 64 returns, 24 pair corners, 8 wall corners |
| dodecagon | centered off-cardinal, cap=300 | 16 returns, 16 pair corners, 16 regular survivors |
| 24-gon | L=2, N=2, cap=100 | 72 returns, 8 wall corners, 16 regular survivors; first survivor reaches a non-cardinal pair facet |

A `CAP` / regular survivor is a finite-horizon classification only. It is not
called chaotic or nonperiodic.
