# Exact 3×3 cardinal-width dodecagon atlas

Model: fixed-orientation regular dodecagons, edge length `1/2`, cardinal width one half of the square-cell side `D=2+sqrt(3)`. Arithmetic is exact `Q(sqrt(3))`.

Raw starts: 576 = C(9,2) * 4^2.

## Outcomes

- RETURN: 424
- PAIR_CORNER: 136
- SIMULTANEOUS: 16

## Ordinary pair-face hits

| face | normal direction | count |
|---:|---|---:|
| 0 | E | 147 |
| 3 | N | 139 |
| 6 | W | 48 |
| 9 | S | 56 |

No ordinary pair collision used faces 1,2,4,5,7,8,10, or 11.

## Pair-corner terminals by first-labelled active face

- 1: 48
- 4: 24
- 7: 20
- 10: 44

The longest regular return has 7 event batches, from sites [0,1] with velocities [N,N], with `T = 21/2 + (21/4)sqrt(3)`.
