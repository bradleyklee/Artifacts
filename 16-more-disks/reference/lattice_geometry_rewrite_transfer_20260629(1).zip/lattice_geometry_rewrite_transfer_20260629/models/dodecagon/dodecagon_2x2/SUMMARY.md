# Exact 2×2 dodecagon atlas

Raw starts: 96

## Outcomes

- PAIR_CORNER: 24
- RETURN: 64
- SIMULTANEOUS: 8

Longest regular-only trajectory: 7 events; start {'sites': [0, 1], 'velocities': ['N', 'N']}; T={'a': '9/2', 'b': '9/4'}

All arithmetic is exact Q(sqrt(3)). Pair corners and every simultaneous batch are terminal classifications.
