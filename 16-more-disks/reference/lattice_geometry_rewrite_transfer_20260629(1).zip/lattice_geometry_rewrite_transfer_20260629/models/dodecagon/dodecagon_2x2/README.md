# Exact 2×2 regular-dodecagon atlas

## Scale contract

* fixed orientation: facet normals at multiples of 30 degrees, including the cardinal axes;
* regular dodecagon edge length: `1/2`;
* apothem: `(2 + sqrt(3))/4`;
* cardinal body width: `(2 + sqrt(3))/2`;
* cell side: `D = 2 + sqrt(3)`, so cardinal body width is exactly `D/2`;
* 2×2 square container: side `2D`, centred at the origin;
* initial centres: all four cell centroids;
* initial velocities: the four unit cardinal directions.

The geometry uses `Q(sqrt(3))`, a subfield of `Q(sqrt(2),sqrt(3),sqrt(6))`.

## Event contract

All arithmetic and equality tests are exact.  A pair event is regular only when exactly one Minkowski-difference support facet is active. Pair vertices are recorded as `PAIR_CORNER` and not continued. Pair+wall coupled batches and same-body wall corners are recorded as `SIMULTANEOUS` and not continued. Two independent one-wall hits commute and are resolved together.

## Results

* raw starts: 96
* exact returns under the regular-event contract: 64
* pair-corner terminals: 24
* coupled simultaneous terminals: 8
* longest return: 7 event batches

`atlas.json` has every raw initial condition, all event records, and the exact elapsed time `T=a+b sqrt(3)` to outcome.  (For the current returns, the repeated state is the initial state, so this is also the cycle time.)
