# Exact 2x2 24-gon atlas

Raw starts: 96

## Outcomes

- CAP: 16
- RETURN: 72
- SIMULTANEOUS: 8

## Regular pair-facet hits

- face 0 (0 deg): 26
- face 1 (15 deg): 28
- face 2 (30 deg): 4
- face 3 (45 deg): 70
- face 4 (60 deg): 4
- face 5 (75 deg): 28
- face 6 (90 deg): 24
- face 7 (105 deg): 18
- face 8 (120 deg): 10
- face 9 (135 deg): 40
- face 10 (150 deg): 2
- face 11 (165 deg): 18
- face 12 (180 deg): 8
- face 13 (195 deg): 8
- face 14 (210 deg): 8
- face 15 (225 deg): 20
- face 16 (240 deg): 8
- face 17 (255 deg): 8
- face 18 (270 deg): 10
- face 19 (285 deg): 18
- face 20 (300 deg): 2
- face 21 (315 deg): 50
- face 22 (330 deg): 10
- face 23 (345 deg): 18

Longest return: 7 event batches; start {'sites': [0, 1], 'velocities': ['N', 'N']}; T={'a': '9/2', 'b': '9/4', 'c': '9/4', 'd': '9/4'}
