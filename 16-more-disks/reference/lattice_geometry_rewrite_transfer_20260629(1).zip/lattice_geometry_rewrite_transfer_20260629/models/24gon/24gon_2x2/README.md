# Exact cardinal-width regular 24-gon: 2x2 NSEW atlas

Model: two fixed-orientation regular 24-gons, edge `1/2`, facet normals at
angles `15*k` degrees, cardinal width exactly half the square cell side.
All scalars use the exact field `Q(sqrt(2),sqrt(3))` with basis
`1,sqrt(2),sqrt(3),sqrt(6)`.

`atlas.json` is a short-horizon (100 event batches) exact atlas. Every
pair vertex contact is a terminal `PAIR_CORNER`; noncommuting simultaneous
batches are `SIMULTANEOUS`; independent wall batches commute.

Important result: this orientation is not trapped in cardinal pair facets.
For example, start sites [0,1], velocities [E,N] has a regular pair hit on
face 3 (normal angle 45 degrees) at event 8, after a prior cardinal pair hit
on face 12 (180 degrees) at event 4. It has no corner/simultaneous event
through 100 event batches.

The 100-event scan results:
- RETURN: 72
- CAP (still regular at 100): 16
- SIMULTANEOUS: 8
- PAIR_CORNER: 0

All 24 face classes occur as ordinary pair-contact facets somewhere in the
short-horizon atlas. The 16 CAP paths need a faster exact sign/caching
engine for deep continuation; they are not classified as nonperiodic.
