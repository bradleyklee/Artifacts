# Lattice Geometry Collision Rewrite — Transfer Packet

This packet preserves the existing exact-model programs and evidence while defining the rewrite target: one exact collision framework for **square, octagon, dodecagon, and 24-gon** lattice/container models.

The post-rewrite classifier must locate, under an explicit ordering, the earliest examples of return, each degeneracy type, off-cardinal scattering, denominator/height growth, and regular nonreturning finite-horizon survivors. Do not call any finite-horizon run “chaos” or “nonperiodic.”

## Headline current witness

`examples/centered_dodecagon_EN/` contains the central dodecagon face-1, `A=E`, `B=N` relative-closing witness:

- exact field `Q(sqrt(3))`;
- dodecagon edge `1/2`, facet normals `30 k` degrees;
- square side `4 × cardinal width`;
- ordinary central pair contact at time zero;
- regular and unrepeated through the recorded horizon;
- facet and ternary words, exact stats, ledger generators, vector diagram, and animation included.

## Packet map

- `legacy/` — intact square/octagon transfer tree, including source, raw data, checksums, and prior docs.
- `models/dodecagon/` — 2×2 and 3×3 exact dodecagon atlas sources + outputs.
- `models/24gon/` — exact 24-gon 2×2 source + short-horizon atlas.
- `examples/centered_dodecagon_EN/` — centered dodecagon programs, data, stats, videos, SVG.
- `data/` — grounded octagon envelope, period, and layer-census results.
- `docs/` — rewrite and classifier contracts.

Read `docs/REWRITE_TARGET.md`, then `docs/CLASSIFIER_CONTRACT.md`, then `docs/CURRENT_EXAMPLE_MATRIX.md`.

## Rules

- Exact arithmetic in the simulation core; float conversion only for rendering.
- Classify complete simultaneous batches. Never silently serialize corners or coupled events.
- Keep state labels, facet conventions, body ordering, and field conventions in every certificate.
- Preserve raw ledgers beside derived reports.
