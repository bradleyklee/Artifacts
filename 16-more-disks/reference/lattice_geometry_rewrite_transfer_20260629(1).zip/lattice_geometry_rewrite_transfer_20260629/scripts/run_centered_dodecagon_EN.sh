#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/examples/centered_dodecagon_EN"
python3 central_offcardinal.py
python3 central_ternary_classes.py
python3 dodeca_stats.py
