# Grounded finite-initial-atlas event-layer census

This is a rerun grounded only in finite physical initial atlases:

- two fixed-orientation regular octagons of edge 1/2;
- container made of an N x N lattice of cells of side 1+sqrt(2);
- every non-overlapping unordered pair of cell-centre starts;
- each body has one of the four unit cardinal velocities NSEW;
- exact Q(sqrt(2)) arithmetic throughout;
- D4 orbit representatives are used only for computation; their orbit weights are retained in all raw counts.

`results_N2_N10_d12.json` is a physical-event-layer census through 12 events.
At each layer it records all surviving starts, pair-hit counts, terminals, state-coordinate coefficient denominators, and pair-contact midpoint/tangent denominators.

Main grounded observation (N=2..10, 199,584 raw starts, 12 event layers):

- both centre-coordinate coefficients have denominators dividing 4;
- pair midpoint rational coefficients have denominators dividing 4;
- pair midpoint sqrt(2) coefficients have denominators dividing 8;
- the unnormalised tangent coordinate u=(-n_y,n_x).(p_B-p_A) is integral in both Q(sqrt(2)) coefficients.

This is an observed finite-atlas result, not a uniform theorem or a closure proof.

Build/run:

    go build -o grounded_layer_census layer_census.go
    ./grounded_layer_census --min-n 2 --max-n 10 --depth 12 --out results.json
