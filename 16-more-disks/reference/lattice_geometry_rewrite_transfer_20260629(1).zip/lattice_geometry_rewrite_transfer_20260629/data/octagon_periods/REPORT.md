# Pair-trajectory coordinate and period envelopes

Conventions:
- `x,y = (p + q sqrt(2))/8`
- `u = (r + s sqrt(2))/2`
- `T = (t + tprime sqrt(2))/2`

All ranges are inclusive. `t` and `tprime` are integer numerators with the shared denominator 2.

| N | p | q | r | s | t | tprime | trajectories | lattice size |
|---:|:--|:--|:--|:--|:--|:--|---:|---:|
| 2 | -5..5 | -3..3 | -1..1 | -1..1 | 2..108 | 2..114 | 5 | 693 |
| 3 | -13..13 | -9..9 | -1..1 | -1..1 | 4..360 | 4..369 | 17 | 4,617 |
| 4 | -21..21 | -15..15 | -5..5 | -3..3 | 6..2936 | 6..2978 | 30 | 102,641 |
| 5 | -37..37 | -19..19 | -6..6 | -9..9 | 8..3184 | 8..3234 | 54 | 722,475 |
| 6 | -33..33 | -23..23 | -7..7 | -5..5 | 10..3644 | 10..3674 | 75 | 519,585 |
| 7 | -41..41 | -27..27 | -9..9 | -7..7 | 12..5240 | 12..5276 | 111 | 1,301,025 |
| 8 | -87..87 | -55..55 | -27..27 | -17..17 | 14..21020 | 14..21232 | 140 | 37,393,125 |
| 9 | -73..73 | -55..55 | -15..15 | -11..11 | 16..20432 | 16..20530 | 188 | 11,634,021 |
| 10 | -121..121 | -65..65 | -21..21 | -29..29 | 18..22764 | 18..22982 | 225 | 80,760,321 |

Every one of the listed distinct D4-canonical first-pair outgoing trajectories returned exactly within the 20,000-event cap. The observed period-coefficient denominators divide 2.
