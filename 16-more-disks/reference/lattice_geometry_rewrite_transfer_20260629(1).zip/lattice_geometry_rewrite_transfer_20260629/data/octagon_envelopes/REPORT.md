# Actual pair-trajectory (x,y,u) lattice envelopes, N=2..10

Exact coefficient convention: `z = a + b*sqrt(2)`, with `a,b` reduced rationals.
`x,y` are pair-contact midpoints. `u=(-n_y,n_x)·(p2-p1)` is the exact unnormalised tangent coordinate at the pair-contact facet.
Every canonical outgoing-packet trajectory was evolved through its exact return. The displayed x/y and u ranges are D4-closed, hence cover all raw NSEW initial conditions represented by each canonical orbit.

| N | outgoing D4 orbits | pair events (representatives) | den(a_x,a_y) | num(a_x,a_y) | den(b_x,b_y) | num(b_x,b_y) | den(a_u) | num(a_u) | den(b_u) | num(b_u) |
|---:|---:|---:|---|---|---|---|---|---|---|---|
| 2 | 5 | 18 | {1,2,4,8} | [-5,5] | {2,4,8} | [-3,3] | {1,2} | [-1,1] | {1,2} | [-1,1] |
| 3 | 17 | 140 | {1,2,4,8} | [-13,13] | {1,2,4,8} | [-9,9] | {1,2} | [-1,1] | {1,2} | [-1,1] |
| 4 | 30 | 610 | {1,2,4,8} | [-21,21] | {1,2,4,8} | [-15,15] | {1,2} | [-5,5] | {1,2} | [-3,3] |
| 5 | 54 | 1274 | {1,2,4,8} | [-37,37] | {1,2,4,8} | [-19,19] | {1,2} | [-6,6] | {1,2} | [-9,9] |
| 6 | 75 | 2224 | {1,2,4,8} | [-33,33] | {1,2,4,8} | [-23,23] | {1,2} | [-7,7] | {1,2} | [-5,5] |
| 7 | 111 | 3254 | {1,2,4,8} | [-41,41] | {1,2,4,8} | [-27,27] | {1,2} | [-9,9] | {1,2} | [-7,7] |
| 8 | 140 | 10228 | {1,2,4,8} | [-87,87] | {1,2,4,8} | [-55,55] | {1,2} | [-27,27] | {1,2} | [-17,17] |
| 9 | 188 | 11796 | {1,2,4,8} | [-73,73] | {1,2,4,8} | [-55,55] | {1,2} | [-15,15] | {1,2} | [-11,11] |
| 10 | 225 | 17178 | {1,2,4,8} | [-121,121] | {1,2,4,8} | [-65,65] | {1,2} | [-21,21] | {1,2} | [-29,29] |

Uniform observation over this tested atlas:

* midpoint coordinates lie in `(1/8) Z[sqrt(2)]`;
* tangent offsets lie in `(1/2) Z[sqrt(2)]`;
* the nonuniform content is only the numerator envelope, which grows with the container scale.
