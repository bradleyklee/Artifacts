# Transfer: exact pair-dynamics artifact

## What is established in the packet

### Baseline geometry

The active octagon baseline is the Artifact-16 four-quadrant half-edge model:

- fixed-orientation regular octagons of edge `1/2`;
- outer square side `2 + 2*sqrt(2)`;
- four canonical starting centres
  `(±(1+sqrt(2))/2, ±(1+sqrt(2))/2)`;
- cardinal unit initial velocities;
- exact arithmetic in `Q(sqrt(2))`.

The primary exact source is
`models/octagon_four_quadrant_halfedge/code/evolve_four_site_search.go`.
Its stored N=2 result is 16 D4 classes, all `RETURN`. This baseline is a
finite lattice atlas, not a theorem about arbitrary continuous offsets.

### Low-level H/V probe

`data/current/hv_firstpass/` and `data/current/hv_low_cases/` are self-
contained exact diagnostic programs and raw output. The first probe finds 7
D4-reduced H/V starts. Five have ordinary pair contacts in the observation
window; two have none within the specified 1000 positive event batches.

The low-case probe records eight ordinary body-body contacts per surviving
class. It shows that a very small collision grammar can support distinct exact
offsets; the state labels alone do not close the system.

### Discarded global product relaxation

The experiment that treated every H-face packet as usable by every H-face
collision graph, and likewise for D, is recorded in
`data/current/global_omega_overapprox/`. It grew rapidly through pass 10.
That experiment is valuable as a negative result only:

- the local template vocabulary settled at eight templates;
- the product-lifted packet sets continued to grow;
- therefore no global `graph × Omega_face` closure was obtained.

It is an over-grammar: it combines packet/graph pairs that may never coexist
on any one physical trajectory. Do **not** use its growth as evidence for
nonperiodicity, chaos, or unavoidable arithmetic-complexity growth.

## Notation — mandatory

Use

```text
X+Y:Z -> X'+Y'
```

where `X`, `Y`, `X'`, `Y'` are track classes in `{H,V,D,F}` and `Z` is the
contact-face class in `{H,V,D}`. `F` means frozen and is valid as either an
input or output. Examples:

```text
H+V:H -> D+F
D+F:D -> D+F
```

Do not replace `F` with `0` in user-facing labels. H/V-related orientations
are reduced under D4 only after the exact state has been constructed.

## Hard constraints

- exact `Q(sqrt(2))` arithmetic for octagons; exact `Fraction` arithmetic for
  the square control;
- no floating-point comparisons, hashes, collision tests, or certificates;
- pair-corner and unresolved shared/simultaneous contacts remain explicit
  terminals unless a separately justified resolution is introduced;
- preserve full offset correlations within a state; do not use independent
  `Omega_H × Omega_D` product closure as a physical model;
- code-generated/vector geometry only; no image generation;
- report only code-executed results and raw output.
