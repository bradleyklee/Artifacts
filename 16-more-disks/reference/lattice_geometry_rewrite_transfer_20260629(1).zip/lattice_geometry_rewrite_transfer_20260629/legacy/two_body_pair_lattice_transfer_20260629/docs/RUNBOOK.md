# Runbook

## Requirements

- Go (standard library only for the bundled Go programs)
- Python 3 (standard library only for the bundled square control)

## Verify packet file hashes

```sh
python3 scripts/verify_manifest.py
```

## Reproduce the first two-contact H/V probe

```sh
cd data/current/hv_firstpass/code
go run two_body_hv_probe.go > ../data/hv_first_two_pair_contacts.rebuilt.json
```

Compare the rebuilt JSON with the committed raw data structurally; field order
or whitespace is not a mathematical difference.

## Reproduce the eight-contact low H/V ledger

```sh
cd data/current/hv_low_cases/code
go run two_body_hv_low_cases.go > ../data/hv_low_cases_8_contacts.rebuilt.json
```

The human-readable CSV is a derived view. Treat JSON as the authoritative raw
ledger.

## Run primary four-quadrant octagon atlas

```sh
cd models/octagon_four_quadrant_halfedge/code
go run evolve_four_site_search.go --bodies=2 --max-state-bits=128   --out /tmp/four_site_n2.json
```

## Run square control

```sh
cd models/square_quarter_edge_control/code
python3 search.py --cap 20000 --out /tmp/four_quadrant_squares.json
```

The command-line options of the archived code are part of its provenance;
inspect `--help` before changing scale or model semantics.

## Beginning the next experiment

Create a new case under `scaffold/runs/` and write its model contract before
executing code. Do not modify the archived source snapshots; copy or import
into a new case-specific source directory.
