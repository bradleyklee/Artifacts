# Periodic annuli, binding, and wrong-turn witnesses

## What to certify for a periodic annulus

Use “periodic annulus” as a working name for one exact periodic two-body
component together with the wall-folded traces of both centres over one least
collision-state period. Do not assume the trace is circular.

Each certificate should include:

```text
model + scale contract
canonical seed state
least collision-state period
number of wall events and ordinary body-body contacts
collision word in X+Y:Z -> X'+Y' notation
exact trace vertices / segments for both bodies
minimal axis-aligned envelope
optional lattice-band / annulus descriptor in the selected lattice metric
max normalized state complexity
return-state equality check
independent replay result
```

“Low-lying” should be an explicit filter, such as maximum complexity, maximum
period, maximum lattice-ring index, or maximum geometric envelope. State the
filter in the output, never implicitly.

## Tightness / binding measures

For each periodic component, calculate exact values such as:

1. **Envelope width:** smallest lattice-aligned bounding box/band containing
   all centre traces.
2. **Centroid clearance:** minimum squared distance from every free-flight
   segment to every background lattice centroid that is not one of the
   designated carrier sites.
3. **Support clearance:** minimum separation between each mover's swept body
   and forbidden lattice-centred body placements, expressed through exact
   support inequalities.
4. **Contact slack:** for each ordinary pair contact, the tangent overlap and
   distance to pair-corner degeneracy.
5. **Wall slack:** minimum distance/time to a competing wall event at each
   collision.

These quantities say whether a clock is tightly guided by the lattice or has
large free room.

## Wrong-turn witness

For a state on a periodic annulus, define a candidate wrong turn as an
alternate finite velocity/track continuation permitted by the chosen local
experiment. Do not silently assume which alternates are physically valid.
For every declared candidate:

```text
start from the exact contact state
continue with the alternate velocity/track rule
find the first t > 0 for which the centre line reaches a background lattice centroid
compare it with the next wall/pair obstruction time
record the first exact event and its reason
```

A useful witness row is:

```text
periodic component, collision index, original output, alternate output,
centroid hit (site), exact hit time, first competing event, verdict
```

Possible verdicts:

```text
CENTROID_BEFORE_OBSTRUCTION
OBSTRUCTED_BEFORE_CENTROID
NO_CENTROID_ON_TRACK_IN_WINDOW
DEGENERATE_OR_UNDEFINED_ALTERNATE
```

This separates “the wrong line geometrically intersects another lattice
centroid” from “a third body would actually be hit there” and from “the wall
prevents reaching that point.”
