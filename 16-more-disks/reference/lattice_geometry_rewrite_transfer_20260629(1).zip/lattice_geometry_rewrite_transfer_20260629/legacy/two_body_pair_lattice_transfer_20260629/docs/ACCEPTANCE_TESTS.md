# Acceptance tests for the next window

A result is not considered complete until it has all applicable entries below.

## Any periodic-pair claim

- exact seed stored;
- exact per-event collision ledger stored;
- canonical return state compared exactly;
- model contract and complexity metric stored;
- corner/simultaneous policy named;
- independent replay/checker passes;
- one code-generated vector trace or exact-data figure produced.

## Complexity-envelope sweep

- finite seed-slice definition and count;
- exact state canonicalization definition;
- complexity cutoff definition;
- state/SCC/terminal/overflow counts per cutoff;
- D4 orbit weights used when reporting percentages;
- overflow not silently included in nonperiodic count.

## Periodic-coverage statistic

Report both:

```text
periodic coverage = certified periodic seeds / all admissible seeds
resolved coverage = (periodic + terminal + declared degeneracies) / all seeds
```

If symmetry reduction is used, reconstruct counts from representative weights.

## Wrong-turn/lattice-centroid result

- alternates are explicitly defined;
- centroid target lattice declared;
- hit and obstruction times are exact;
- output distinguishes geometric centroid interception from actual additional-
  body collision.
