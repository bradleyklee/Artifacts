# Next-window plan

The requested objectives are intentionally ordered from cheap/local to
exhaustive/global.

## 1. Continue the pair artifact

Work from the exact two-body engine, not from the global-Omega relaxation.
Create a new compact case directory per model/scale/lattice size with:

```text
README.md
code/
data/seeds/
data/runs/
data/certificates/
figures/
```

Every run must preserve exact raw initial states, a per-body-body-contact
ledger, terminal reason, and an independently checkable return certificate.

## 2. Octagon pairs, then square pairs, at the requested half-width lattice scale

First make the scale contract explicit. “Half-width compared to lattice-square
size” needs a declared denominator:

```text
lattice cell side = ell
body support width in the relevant direction = w
requested ratio = w / ell = 1/2
```

Record whether `w` means edge length, horizontal support width, or another
normal-direction support width. The existing octagon model is a half-edge
four-quadrant model; verify it against this contract before treating it as the
target normalization.

The square source bundled here is *not automatically the same target*: it is
an axis-aligned square control with outer edge 4 and mover edge 1. Use it as a
reference/control, then parameterize the desired half-width square version.

## 3. Enumerate all low-lying periodic annuli

For each small lattice slice:

1. enumerate all admissible two-body seeds exactly, with a declared finite
   position lattice and finite velocity family;
2. run to a return, legitimate terminal, corner/simultaneous terminal, or
   complexity overflow;
3. canonicalize periodic components by exact collision-state return and their
   one-period geometric trace;
4. group equivalent components under D4, particle interchange, and lattice
   translation when the model permits it;
5. write one certificate per periodic annulus/component.

“Annulus” should be represented by its actual exact trace envelope, not merely
by a picture. The required fields are listed in
`PERIODIC_ANNULI_AND_WRONG_TURNS.md`.

## 4. Infer a complexity envelope, then brute-force it

A periodic orbit has a finite maximum normalized-state complexity. For a bound
`B`, construct the finite deterministic state graph reachable from the chosen
finite seed slice while retaining only states of complexity at most `B`.

Sweep `B` upward. Track:

```text
B | seeds | states | periodic SCCs | returned seeds | terminals |
  | degenerate terminals | overflow seeds | max observed period
```

A closed nonterminal finite component is a periodicity certificate for all
states in that component. An overflow is unresolved, not nonperiodic.

## 5. Measure binding and wrong-turn exposure

For every certified periodic annulus, compute the exact geometric envelope and
ask where a different allowable direction/branch would place a free-flight
line through another lattice centroid. Keep this as a separate exact witness
rather than an informal visual claim.

See `PERIODIC_ANNULI_AND_WRONG_TURNS.md` for the measurement definitions.
