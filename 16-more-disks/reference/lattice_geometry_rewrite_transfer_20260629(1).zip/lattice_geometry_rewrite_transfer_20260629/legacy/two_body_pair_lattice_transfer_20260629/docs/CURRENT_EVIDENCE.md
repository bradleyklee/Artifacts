# Current evidence ledger

This file separates executed data from proposed next steps.

## Exact low-level source files

- `data/current/hv_firstpass/` — seven D4-reduced H/V initial classes in the
  four-quadrant half-edge octagon model; exact first two body-body contacts
  when present.
- `data/current/hv_low_cases/` — exact eight body-body-contact ledgers for
  the low H/V classes.
- `data/current/global_omega_overapprox/` — exact but intentionally relaxed
  global-product closure experiment; retained as a negative-method result.

## What the low ledgers show

The low-case data contains ordinary examples of both:

```text
H+V:H -> D+F
D+F:D -> D+F
D+F:H/V -> H+V
H+V:D -> H+V
```

with orientation-specific labels in the raw CSV. The user-facing notation
should reduce H/V orientations only after exact-state analysis. Distinct
contact offsets occur even while the coarse local collision template repeats.

The raw data, not this prose, is authoritative for individual times, faces,
centres, and velocity assignments.

## What the global-Omega experiment does and does not show

Through pass 10 the deliberately relaxed product calculation grew from
`(Omega_H, Omega_D)=(1,1)` to `(14345,8897)` while its local template count
was eight. This is evidence that the *unrestricted product relaxation* does
not give a small closure. It is not an orbit count and not evidence that any
specific physically valid orbit has unbounded complexity.

## Do not reuse these invalid inferences

- “the graph stabilized at eight” does not mean the offset-lifted contact
  graph stabilized;
- global packet-count growth is not a complexity-growth proof;
- a fixed denominator over a few relaxed rounds is not a periodicity proof;
- a long exact run without return is not evidence of nonperiodicity.
