# Collision state and complexity cutoff

## Exact collision-state key

At an ordinary body-body contact, reset time to zero and store:

```text
shape model and scale contract
container/lattice identifier
ordered or canonically ordered body centres p1, p2 in Q(sqrt(2))^2
velocities v1, v2 in the finite unit-velocity family
active pair-contact face
contact type X+Y:Z -> X'+Y'
```

Then canonicalize by all model-preserving symmetries that are explicitly
allowed: D4, particle swap, and lattice translation only where translation is
a genuine symmetry of the finite-container problem. The canonicalization must
act on the *entire exact state*, not only on a local face label or centroid.

A full offset packet is correlated state data. At minimum it contains the
collision midpoint and the relative contact vector, or equivalently the two
body centres at contact. Never break it into independently mixable face
alphabets unless the calculation is explicitly declared an over-approximation.

## Complexity measure

Represent each exact coordinate as

```text
a + b*sqrt(2), with a,b in Q in lowest terms.
```

For one normalized state `s`, record at least:

```text
den(s)    = lcm of every rational denominator appearing in a and b
height(s) = max absolute numerator after putting all coefficients over den(s)
bits(s)   = bit length of max(1, height(s), den(s))
```

Track the conjugate-coordinate data too: bounding the physical coordinate
`a+b*sqrt(2)` alone does not bound `a` and `b`, because cancellation can make
it small while coefficients grow. The coefficient-height cutoff is therefore
part of the mathematical state condition, not just an implementation guard.

A recommended lexicographic cutoff is:

```text
complexity(s) = (bits(s), den(s), height(s))
```

or a scalar `B` that bounds all three. Store the exact definition in every
certificate.

## Finite-graph principle

For a fixed finite model, finite velocity alphabet, and a fixed complexity
bound, the set of normalized exact collision states is finite. The exact
next-event map is deterministic away from explicitly terminal degeneracies.
Therefore any forward-closed nonterminal component is eventually periodic; a
strongly connected component is purely periodic.

This is the desired brute-force certificate. It does **not** say an overflow
state is nonperiodic. It says only that the selected envelope was insufficient.

## Required status labels

```text
RETURN          exact state return
PERIODIC_SCC    belongs to a closed periodic component
TERMINAL_FREE   no future body-body collision; wall motion may still continue
TERMINAL_CORNER pair-corner/mixed contact under current policy
TERMINAL_SIMULTANEOUS unresolved simultaneous shared-body event
OVERFLOW        exceeded declared complexity envelope
INVALID         violated model contract
```
