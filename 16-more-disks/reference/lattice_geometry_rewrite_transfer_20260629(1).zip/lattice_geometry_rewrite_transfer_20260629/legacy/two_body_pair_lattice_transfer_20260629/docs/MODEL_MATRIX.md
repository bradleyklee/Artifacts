# Model matrix

| Model | Current status | Role next window |
|---|---|---|
| Four-quadrant half-edge fixed octagons | Exact Q(sqrt(2)); N=2 atlas returns; low H/V probes bundled | Primary pair model |
| Desired octagon half-width lattice family | Scale contract not yet written in a parameterized model | First new construction |
| Existing quarter-edge square control | Exact Fraction; finite N=2/N=3 atlas with returns/corners/simultaneous terminals | Contrast/control only |
| Desired square half-width lattice family | Not yet built | Optional parallel/control experiment |
| Artifact-15 C4 multi-body clocks | Independently checked reference material | Proof/certificate design reference, not pair closure evidence |

Never conflate the container scale, lattice-cell scale, body edge, and support
width. Every new case must state them all explicitly.
