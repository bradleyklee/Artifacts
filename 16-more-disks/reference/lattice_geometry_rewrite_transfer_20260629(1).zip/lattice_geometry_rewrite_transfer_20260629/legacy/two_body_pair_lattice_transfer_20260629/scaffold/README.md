# New-case scaffold

Create one subdirectory per exact model/scale/lattice-size experiment. Suggested
layout:

```text
case_name/
  README.md              model contract and scope
  code/                  case-specific producer + independent checker
  data/seeds/            exact initial states
  data/runs/             raw event ledgers
  data/certificates/     periodic/SCC/coverage certificates
  figures/               code-generated SVG/PDF/PNG only
  summaries/             CSV/JSON reporting tables
```

Do not mix model revisions or cutoff policies in one output directory.
