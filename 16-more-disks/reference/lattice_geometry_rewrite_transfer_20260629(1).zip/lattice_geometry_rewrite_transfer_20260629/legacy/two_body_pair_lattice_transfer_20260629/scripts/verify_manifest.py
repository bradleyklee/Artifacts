#!/usr/bin/env python3
from pathlib import Path
import hashlib

root = Path(__file__).resolve().parents[1]
manifest = root / 'SHA256SUMS'
failed = 0
for line in manifest.read_text().splitlines():
    if not line.strip():
        continue
    expected, rel = line.split('  ', 1)
    path = root / rel
    got = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else '<missing>'
    if got != expected:
        print(f'FAIL {rel}: expected {expected}, got {got}')
        failed += 1
    else:
        print(f'OK   {rel}')
raise SystemExit(1 if failed else 0)
