# Two-body lattice-pair transfer packet — 2026-06-29

This packet carries the exact two-body hard-octagon pair work into the next
window. The immediate target is **small, auditable periodic pair dynamics**,
not an unbounded global grammar.

Read in this order:

1. `docs/TRANSFER.md` — scope, current conclusions, and strict constraints.
2. `docs/NEXT_WINDOW_PLAN.md` — the five requested objectives and execution order.
3. `docs/STATE_AND_COMPLEXITY.md` — collision notation, exact state key, and
   a usable complexity cutoff.
4. `docs/PERIODIC_ANNULI_AND_WRONG_TURNS.md` — proposed certificates for
   bounded periodic annuli and lattice-centroid interception.
5. `docs/RUNBOOK.md` — reproducible starting commands.

The raw, exact two-body H/V probes live under `data/current/`. The global
Omega closure material is retained only as a documented *over-approximation
that proliferated*; it must not be mistaken for a physical-orbit enumeration.

All evolution must stay exact. No floats in collision logic, state keys,
comparisons, or certificates.
