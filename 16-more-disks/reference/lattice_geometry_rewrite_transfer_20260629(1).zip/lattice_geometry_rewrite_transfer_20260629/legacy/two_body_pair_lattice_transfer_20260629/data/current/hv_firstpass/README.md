# First two-body H/V offset probe

This is the first deliberately small test of the offset-closure idea.

## Scope

Geometry is the exact four-quadrant half-edge model used by the Artifact 16
search:

- fixed-orientation regular octagons of edge `1/2`;
- square side `2 + 2*sqrt(2)`;
- four starting centers `(±(1+sqrt(2))/2, ±(1+sqrt(2))/2)`;
- two bodies only;
- one horizontal and one vertical unit-velocity track at the raw start;
- exact `Q(sqrt(2))` arithmetic throughout;
- walls are resolved exactly between mutual contacts, but only body-body
  contacts are reported.

The probe scans the H/V sub-atlas, reduces initial starts by D4, then records
the first two ordinary one-face body-body contacts for every surviving class.
Pair-corner contacts would be terminal; none occur in the five classes with a
pair contact here.

## Exact result

The H/V sub-atlas has `7` D4 classes. Two have no body-body contact during the
first `1000` positive event batches. The other five yield:

- first H/cardinal-face collision: 3 classes;
- first D/diagonal-face collision: 2 classes.

Modulo D4, the first H collision centroid has one orbit:

```text
C_H = ((1+sqrt(2))/2, -(1+sqrt(2))/4)
```

and the first D collision centroid has one orbit:

```text
C_D = (1/4 + 3*sqrt(2)/8, -1/4 - 3*sqrt(2)/8).
```

All five initial contacts are centered on their active relative-octagon face:
the relative contact coordinate along the face is zero. Thus the initial
H/V grid introduces no nonzero local face offset.

At the next body-body collision, three transition patterns occur:

```text
H -> H at C_H       (1 class)
D -> D at C_D       (2 classes)
H -> D at C_X       (2 classes)
```

where, modulo D4,

```text
C_X = (-1/4 - 3*sqrt(2)/8, 1/4 + sqrt(2)/8).
```

`C_X` is the first new global centroid/wall-phase orbit. It is not D4-equivalent
to `C_H` or `C_D`. Its contact is still face-centered; the novelty is the
centroid phase, not a new coordinate along the contact face.

The H-face collision sends the incoming H/V pair to a D/0 pair. Depending on
its wall phase, that D/0 pair returns at H or at D. The D-face collision sends
H/V to H/V (the velocity ownership swaps), and both observed D starts return
at the same D centroid orbit.

## Reproduction

```sh
cd code
go run two_body_hv_probe.go > ../data/hv_first_two_pair_contacts.json
```

The program is a self-contained copy of the exact Artifact 16 engine with a
replacement diagnostic `main`. `source_provenance.txt` names and hashes the
primary source from which it was made.
