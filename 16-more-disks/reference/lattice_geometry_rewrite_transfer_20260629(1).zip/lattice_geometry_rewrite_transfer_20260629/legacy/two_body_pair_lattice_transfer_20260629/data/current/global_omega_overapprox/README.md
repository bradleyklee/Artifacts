# Global-Omega over-approximation archive

This directory stores an exact, deliberately relaxed test. It is not a physical
state-graph enumeration. It assumes every normalized H-face packet may be used
by every known H-face collision template and likewise for D. The resulting
product closure grew through pass 10.

Use it only to avoid repeating this broad product relaxation without stronger
compatibility relations. Do not use it to infer nonperiodicity or offset
complexity of an actual trajectory.
