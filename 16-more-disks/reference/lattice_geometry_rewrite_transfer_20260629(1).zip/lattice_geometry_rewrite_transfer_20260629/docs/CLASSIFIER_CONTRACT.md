# Earliest-Example Classifier Contract

## Scope

For every basic model, run declared atlas families and identify the earliest witness under a published ordering. “Looks chaotic” is not a classifier label.

## Ordering

For lattice starts use lexicographic order:

```text
model rank -> N -> orientation/phase -> canonical unordered site pair
-> ordered velocity pair -> event time/index
```

For centered-contact starts use:

```text
face class -> face label -> ordered incoming velocity pair -> event time/index
```

Every certificate states its ordering and symmetry quotient.

## Required labels

```text
EARLIEST_RETURN
EARLIEST_PAIR_CORNER
EARLIEST_WALL_CORNER
EARLIEST_COUPLED_SIMULTANEOUS
EARLIEST_INDEPENDENT_WALL_BATCH
EARLIEST_OFFCARDINAL_PAIR_FACE
EARLIEST_DENOMINATOR_PROMOTION
EARLIEST_COEFFICIENT_HEIGHT_GROWTH
EARLIEST_REGULAR_HORIZON_SURVIVOR
```

## Regular-survivor certificate

```text
horizon event count
complete event-class list
no repeated canonical state through horizon
full facet word + reduced word
first appearance of each facet class
max exact numerator / denominator by coordinate group
```

Report earliest examples per model before any cross-model comparison.
