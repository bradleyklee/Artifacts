# Current Example Matrix — Provisional Until Rewrite Reproduces It

| family | current evidence | source |
|---|---|---|
| square quarter-edge control | finite control search, representatives/result JSON | `legacy/two_body_pair_lattice_transfer_20260629/models/square_quarter_edge_control/` |
| octagon 4.8.8 / half-edge | finite searches, HV contact work, complexity envelopes | `legacy/.../octagon_four_quadrant_halfedge/`; `data/octagon_*` |
| dodecagon 2×2 cardinal | returns plus pair-corner and coupled-simultaneous terminals | `models/dodecagon/dodecagon_2x2/` |
| dodecagon 3×3 cardinal | archived scan reports no regular off-cardinal pair facet hit | `models/dodecagon/dodecagon_3x3/` |
| dodecagon centered off-cardinal | face 1, A=E, B=N regular finite-horizon witness with ternary word | `examples/centered_dodecagon_EN/` |
| 24-gon 2×2 cardinal | tilted regular facet hits and horizon survivors in short atlas | `models/24gon/24gon_2x2/` |

## Centered dodecagon conventions

- edge `1/2`; apothem `(2+sqrt(3))/4`
- box side `4 × cardinal width = 8 × apothem`
- facet label `k` means normal angle `30k` degrees
- pair label `k` means A facet `k`, B facet `k+6 mod 12`
- ternary digit is `k mod 3`
- all current calculations use `Q(sqrt(3))`

## Caveats

- A finite horizon is not a nonperiodicity proof.
- Distinguish denominator growth from numerator/height growth.
- Degenerate contact labels are classifications, not resolved collisions.
