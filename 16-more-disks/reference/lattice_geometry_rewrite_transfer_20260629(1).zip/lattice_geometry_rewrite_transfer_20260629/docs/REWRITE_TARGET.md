# Rewrite Target

## Architecture

```text
exact scalar field
 -> polygon/support geometry
 -> lattice + container geometry
 -> exact candidate-event generator
 -> complete same-time batch classifier
 -> ordinary-event resolver
 -> canonicalizer/state key
 -> atlas search + earliest-witness minimizer
 -> certificate/statistics/vector renderer
```

## Exact scalar fields

| model | field |
|---|---|
| square | Q |
| octagon | Q(sqrt(2)) |
| dodecagon | Q(sqrt(3)) |
| 24-gon | Q(sqrt(2),sqrt(3)) = Q(sqrt(2),sqrt(3),sqrt(6)) |

Do **not** assume velocities lie in a finite alphabet: pair collisions can generate unbounded exact coefficients.

## Geometry interface

```text
facet_count
facet_normal(k)
support_distance
opposite_facet(k)
pair-contact support test
container wall geometry
orientation and labeling convention
```

## Event classes

```text
PAIR_FACE
PAIR_CORNER
WALL_FACE
WALL_CORNER
INDEPENDENT_WALL_BATCH
COUPLED_SIMULTANEOUS
NO_EVENT
```

Only `PAIR_FACE`, `WALL_FACE`, and `INDEPENDENT_WALL_BATCH` resolve automatically.

## Required trace fields

```text
model_id, field, geometry_version
case_id, raw_start_id, canonical_start_id
step, exact_dt, exact_T
event_class, full batch
body ids, pair facet labels, wall labels
pre/post state, canonical state hash
position/velocity numerator and denominator statistics
```

## Required commands

```text
make test
make atlas MODEL=square N=...
make atlas MODEL=octagon N=...
make atlas MODEL=dodecagon N=...
make atlas MODEL=24gon N=...
make centered MODEL=dodecagon FACE=1 VA=E VB=N
make classify MODEL=... INPUT=...
make render CASE=...
make certificate CASE=...
```

## Acceptance gates

1. Reproduce selected legacy square/octagon certificates.
2. Reproduce current dodecagon 2×2 and 3×3 atlas status counts.
3. Reproduce centered dodecagon face-1 `E,N` initial ledger and ternary prefix.
4. Reproduce the current 24-gon tilted-face witness.
5. Emit exact JSON/CSV certificates and code/vector-only visual outputs.
