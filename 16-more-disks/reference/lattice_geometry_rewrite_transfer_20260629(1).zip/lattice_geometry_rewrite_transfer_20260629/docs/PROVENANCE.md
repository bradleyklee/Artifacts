# Provenance

Assembled 2026-06-29 from these source archives:

```text
two_body_pair_lattice_transfer_20260629(1).zip
dodecagon_2x2_exact_atlas.zip
dodecagon_3x3_exact_atlas.zip
24gon_2x2_exact_short_horizon_atlas.zip
centered_offcardinal_dodecagon_experiment.zip
centered_dodecagon_all_ternary_face_classes_500.zip
central_dodecagon_EN_12000_stats.zip
```

Video/SVG outputs are data-driven renderings. Exact simulation code is retained separately. Verify all included files with `sha256sum -c SHA256SUMS`.
