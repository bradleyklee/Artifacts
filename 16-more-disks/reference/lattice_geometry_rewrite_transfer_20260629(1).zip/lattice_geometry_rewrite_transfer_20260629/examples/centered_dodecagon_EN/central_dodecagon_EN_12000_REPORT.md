# Central dodecagon E,N runner — 12,000-event exact census

## Seed

- Square side: four dodecagon cardinal widths.
- Central prescribed face: `1` (ternary class `1`).
- Incoming velocities: `(E,N)`.
- Exact arithmetic: `Q(sqrt(3))`.
- Pair-face word includes the central collision as its first digit.

## Run status

The trace reached 12,000 physical event batches with no recurrence, pair corner, or coupled simultaneous batch. It contains 2,535 body-body pair collisions.

## Ternary word statistics

| quantity | value |
|---|---:|
| digit counts (0,1,2) | 924, 831, 780 |
| one-symbol entropy | 1.581396 bits (maximum is log2(3)=1.584963) |
| conditional next-symbol entropy | 1.573549 bits |
| distinct 3-blocks | 27 / 27 |
| largest constant-symbol run | 18 |
| chi-square against uniform single digits | 12.6178 on 2 df; p ~= 0.00182 |
| chi-square against uniform ordered pairs | 54.7680 on 8 df; p ~= 5.1e-9 |
| lag-1 equality rate | 0.38319 (uniform iid benchmark: 1/3) |
| lag-50 equality rate | 0.33239 |
| maximum exact coefficient denominator bit length | 890 |

The pair counts are:

```text
00 377   01 290   02 256
10 289   11 306   12 236
20 258   21 234   22 288
```

## Comparison prefixes

All comparisons use ternary fractional digits of the same length (2,535):

| source | single-digit chi2 | pair chi2 | conditional entropy |
|---|---:|---:|---:|
| dodecagon runner | 12.62 | 54.77 | 1.57355 |
| sqrt(2) | 0.31 | 2.64 | 1.58430 |
| sqrt(3) | 1.93 | 11.54 | 1.58221 |
| pi | 4.49 | 13.17 | 1.58257 |
| e | 0.29 | 2.72 | 1.58427 |
| phi | 2.93 | 12.79 | 1.58215 |

This does not establish non-normality or non-algebraicity. It only says that this deterministic collision word has statistically visible local dependence at this length, unlike these comparison prefixes.

## OEIS / exact-prefix check

No exact-prefix hit was returned by a web search on the 30-digit initial word. That is a weak negative result, not a meaningful identification test.
