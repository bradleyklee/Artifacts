# Central dodecagon collision: ternary face classes

Model: regular dodecagons, cardinal width half a cell, square box of side four
cardinal widths.  The contact midpoint is the box center.  Each seed is a
strictly relative-closing NSEW ordered pair at a prescribed central face,
resolved elastically at time zero.  The pair-face word includes that prescribed
central collision as its first symbol, reduced modulo 3.

All calculations use exact Q(sqrt(3)) arithmetic.  The horizon is 500 event
batches.  `CAP` means regular/no recurrence/no terminal through the horizon.

## Face-class representatives

- class 0: face 0
- class 1: face 1
- class 2: face 2

Square D4 rotations carry every other face in a class to its representative.

## Long runners

Class 1, incoming (E,N) and (S,W), identical ternary pair word:

```
102102121222122202202110222112000122121022210102102001122000022112100200101121121100201100222012011012112101
```

Class 2, incoming (W,S) and (N,E), identical ternary pair word:

```
201201212111211101101220111221000211212011120201201002211000011221200100202212212200102200111021022021221202
```

Both words have 108 body-body collisions, including the central collision at
time zero, and are regular/nonrecurrent through 500 total event batches.

## Full result counts for representatives

- RETURN: 5
- PAIR_CORNER: 8
- CAP (long runner): 4

Class 0 has 5 strict incoming NSEW pairs because N and S have the same normal
component at the cardinal face; no class-0 long runner occurs.
