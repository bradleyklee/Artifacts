# Centered off-cardinal dodecagon collision

## Geometry

- Regular dodecagons, edge `1/2`.
- Fixed facet normals at angles `0,30,...,330` degrees.
- Apothem `a=(2+sqrt(3))/4`.
- Square container from the existing 2x2 cardinal-width model: half-side `2+sqrt(3)`.
- All arithmetic is exact in `Q(sqrt(3))`.

## Canonical seed

The two centres begin at the central face-contact configuration for face 1
(normal `n=(sqrt(3)/2,1/2)`):

```text
A(0) = -a n
B(0) = +a n
incoming velocities = (E,N)
```

They are resolved by the ordinary face collision at time zero. The exact
outgoing velocities are:

```text
vA = ((1+sqrt(3))/4, (1-sqrt(3))/4)
vB = ((3-sqrt(3))/4, (3+sqrt(3))/4)
```

## Exact 500-event result

- No return detected through 500 event batches.
- No pair-corner contact.
- No coupled simultaneous event.
- 107 regular pair contacts.
- All 12 pair-facet classes occur by step 200.

At step 500,

```text
T = 2353179148286069/5610388152668
  + 3883129832421329/16831164458004 * sqrt(3)
```

Maximum coefficient sizes seen in the state through step 500:

```text
positions: numerator 153835946087593, denominator 33662328916008
velocities: numerator 14821725, denominator 16777216
time: numerator 3883129832421329, denominator 16831164458004
```

## Small central-face sweep

For every off-cardinal face and every cardinal incoming velocity pair that
approaches that face, resolving the collision at time zero gives 48 cases.
At 300 event batches:

```text
16 return
16 pair-corner terminal
16 regular nonreturning at the cap
```

The CAP cases are D4-related versions of the same off-cardinal mechanism.
