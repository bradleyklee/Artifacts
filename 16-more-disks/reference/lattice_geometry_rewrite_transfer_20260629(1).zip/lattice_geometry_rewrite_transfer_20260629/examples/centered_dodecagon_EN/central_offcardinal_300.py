import sys,json
sys.path.insert(0,'/mnt/data/dodecagon_2x2')
import dodecagon_2x2 as m

# Centered contact: midpoint=0; relative center=2a*n(face).
# For each cardinal incoming pair that genuinely approaches this face, resolve
# its collision at time zero, then evolve the outgoing state exactly.

def clonep(p): return m.P(p.pos,p.vel)

out=[]
for face in [1,2,4,5,7,8,10,11]:
    n=m.normals[face][1]
    pos0=n.scale(-m.apothem)
    pos1=n.scale(m.apothem)
    for ia,va in enumerate(m.vels):
      for ib,vb in enumerate(m.vels):
        g=m.dot(n,vb-va)
        # incoming if relative velocity points inward relative to d=2a n
        if g.sign()>=0: continue
        ps=[m.P(pos0,va),m.P(pos1,vb)]
        # resolve collision at t=0 -> outgoing state
        m.resolve(ps,m.Event(m.Z,'pair',0,1,face,()))
        r=m.run(ps,cap=300)
        r2={k:v for k,v in r.items() if k!='events'}
        for key in ('T','cycle_T'):
            if key in r2: r2[key]=r2[key].wire()
        r2['face']=face
        r2['incoming']=[m.velnames[ia],m.velnames[ib]]
        r2['outgoing']=[ps[0].vel.key(),ps[1].vel.key()]
        r2['initial_gap_dot']=g.wire()
        # first 25 faces / event types
        r2['prefix']=[{'kind':e['kind'],'face':e['face'],'wall':e['wall']} for e in r['events'][:25]]
        out.append(r2)

from collections import Counter
c=Counter(x['status'] for x in out)
print('cases',len(out),'counts',dict(c))
for x in out:
  if x['status'] in ('CAP','RETURN'):
    # prints long or very long
    print(x['face'], x['incoming'], x['status'],x['steps'], x.get('period_events'),x.get('T'), x['prefix'][:12])
with open('/mnt/data/dodecagon_2x2/central_offcardinal.json','w') as f:
 json.dump({'model':'centered off-cardinal contact; resolve cardinal incoming collision at t=0 then evolve','cap':5000,'cases':out,'counts':dict(c)},f,indent=2)
