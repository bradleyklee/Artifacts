#!/usr/bin/env python3
"""Exact 2x2 hard-dodecagon atlas.

Model:
- fixed-orientation regular dodecagons whose facet normals are at 0,30,...,330 deg;
- edge length 1/2; apothem a=(2+sqrt(3))/4;
- cardinal width 2a=(2+sqrt(3))/2, exactly half the square cell side D=2+sqrt(3);
- square 2x2 container of side 2D, cell centroids (+/-D/2,+/-D/2);
- two bodies; initial velocities in NSEW; exact Q(sqrt(3)) arithmetic.

Q(sqrt(3)) is a subfield of Q(sqrt(2),sqrt(3),sqrt(6)), so this is fully
inside the requested exact field.  Every non-single-facet pair contact and
every simultaneous event batch is terminally classified, never serialised.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations, product
import json, os, hashlib

@dataclass(frozen=True)
class Q3:
    a: F = F(0)
    b: F = F(0)
    def __add__(self,o): return Q3(self.a+o.a,self.b+o.b)
    def __sub__(self,o): return Q3(self.a-o.a,self.b-o.b)
    def __neg__(self): return Q3(-self.a,-self.b)
    def __mul__(self,o):
        if isinstance(o,Q3): return Q3(self.a*o.a+3*self.b*o.b, self.a*o.b+self.b*o.a)
        return Q3(self.a*o,self.b*o)
    __rmul__=__mul__
    def inv(self):
        den=self.a*self.a-3*self.b*self.b
        if den == 0: raise ZeroDivisionError
        return Q3(self.a/den,-self.b/den)
    def __truediv__(self,o): return self*o.inv() if isinstance(o,Q3) else Q3(self.a/o,self.b/o)
    def sign(self):
        if self.b == 0: return (self.a>0)-(self.a<0)
        if self.a == 0: return (self.b>0)-(self.b<0)
        if (self.a>0)==(self.b>0): return 1 if self.a>0 else -1
        # compare |a| and |b|sqrt3
        c=(self.a*self.a > 3*self.b*self.b)-(self.a*self.a < 3*self.b*self.b)
        return c if self.a>0 else -c
    def key(self): return f'{self.a.numerator}/{self.a.denominator};{self.b.numerator}/{self.b.denominator}'
    def wire(self): return {'a':str(self.a),'b':str(self.b)}
    def approx(self): return float(self.a)+float(self.b)*(3**.5)

Z=Q3(); ONE=Q3(F(1)); HALF=F(1,2)
S3=Q3(F(0),F(1))

def q(n=0,d=1): return Q3(F(n,d))

@dataclass(frozen=True)
class V:
    x: Q3; y: Q3
    def __add__(self,o): return V(self.x+o.x,self.y+o.y)
    def __sub__(self,o): return V(self.x-o.x,self.y-o.y)
    def scale(self,t): return V(self.x*t,self.y*t)
    def key(self): return self.x.key()+','+self.y.key()

def dot(a:V,b:V)->Q3: return a.x*b.x+a.y*b.y

# unit facet normals.  All norms are exactly one.
normals=[]
# k=0..11 angles 30*k. Values belong Q(sqrt3).
vals=[(q(1),Z),(S3*HALF,q(1,2)),(q(1,2),S3*HALF),(Z,q(1)),(-q(1,2),S3*HALF),(-(S3*HALF),q(1,2)),(-q(1),Z),(-(S3*HALF),-q(1,2)),(-q(1,2),-(S3*HALF)),(Z,-q(1)),(q(1,2),-(S3*HALF)),(S3*HALF,-q(1,2))]
for k,(x,y) in enumerate(vals): normals.append((k,V(x,y)))

# edge=1/2; apothem = edge/(2 tan(pi/12)) = (2+sqrt3)/4
apothem=(q(2)+S3)/4
D=q(2)+S3                 # cell side
BOX=D                         # half container side for 2x2
sites=[V(-D/2,-D/2),V(-D/2,D/2),V(D/2,-D/2),V(D/2,D/2)]
vels=[V(q(1),Z),V(-q(1),Z),V(Z,q(1)),V(Z,-q(1))]
velnames=['E','W','N','S']

@dataclass
class P:
    pos: V; vel: V
    def key(self): return self.pos.key()+'@'+self.vel.key()
@dataclass
class Event:
    t: Q3; kind: str; i:int; j:int|None=None; face:int|None=None; walls:tuple=()

def active_faces(d:V):
    return [k for k,n in normals if dot(n,d)==apothem*2]
def inside(d:V):
    return all(dot(n,d).sign()<= (apothem*2-dot(n,d)).sign()+0 for _,n in normals) # replaced below

def is_inside(d:V):
    for _,n in normals:
        if (dot(n,d)-apothem*2).sign()>0: return False
    return True

def pair_candidate(ps,i,j):
    d=ps[j].pos-ps[i].pos
    rel=ps[j].vel-ps[i].vel
    best=None
    for k,n in normals:
        der=dot(n,rel)
        gap=dot(n,d)-apothem*2
        if der.sign()>=0 or gap.sign()<=0: continue
        t=(-gap)/der
        if t.sign()<=0: continue
        loc=d+rel.scale(t)
        if not is_inside(loc) or (dot(n,loc)-apothem*2).sign()!=0: continue
        if best is None or (t-best[0]).sign()<0: best=(t,k)
    if best is None: return None
    t,k=best; loc=d+rel.scale(t); af=active_faces(loc)
    return Event(t,'pair',i,j,k,()) if len(af)==1 else Event(t,'pair_corner',i,j,k,())

def wall_candidates(ps,i):
    p=ps[i]; out=[]
    # body support along cardinal axes is apothem.
    for axis,sgn,name in [(0,1,'E'),(0,-1,'W'),(1,1,'N'),(1,-1,'S')]:
        coord=p.pos.x if axis==0 else p.pos.y
        vv=p.vel.x if axis==0 else p.vel.y
        target=BOX-apothem if sgn>0 else -BOX+apothem
        speed=vv if sgn>0 else -vv
        gap=(target-coord) if sgn>0 else (coord-target)
        if speed.sign()>0 and gap.sign()>0:
            out.append(Event(gap/speed,'wall',i,None,None,(name,)))
    return out

def next_batch(ps):
    es=[]
    for i in range(2): es+=wall_candidates(ps,i)
    pc=pair_candidate(ps,0,1)
    if pc: es.append(pc)
    if not es: return None
    t=min(es,key=lambda e:e.t.approx()).t
    # exact select since approximate only used choice; verify min exact
    for e in es:
        if (e.t-t).sign()<0: t=e.t
    batch=[e for e in es if (e.t-t).sign()==0]
    # Pair vertices and coupled components are not assigned a continuation.
    if any(e.kind=='pair_corner' for e in batch): return batch,'PAIR_CORNER'
    if len(batch)==1: return batch,'REGULAR'
    # Independent one-wall hits of distinct bodies commute and are regular.
    if all(e.kind=='wall' for e in batch) and len({e.i for e in batch})==len(batch):
        return batch,'INDEPENDENT_WALL_BATCH'
    return batch,'SIMULTANEOUS'

def advance(ps,t):
    for p in ps: p.pos=p.pos+p.vel.scale(t)

def resolve(ps,e):
    if e.kind=='wall':
        w=e.walls[0]; p=ps[e.i]
        if w in ('E','W'): p.vel=V(-p.vel.x,p.vel.y)
        else: p.vel=V(p.vel.x,-p.vel.y)
    else:
        a,b=ps[e.i],ps[e.j]; n=normals[e.face][1]
        g=dot(n,b.vel-a.vel)
        a.vel=a.vel+n.scale(g)
        b.vel=b.vel-n.scale(g)

def statekey(ps): return ps[0].key()+'|'+ps[1].key()

def raw_label(a,b,ia,ib): return {'sites':[a,b],'velocities':[velnames[ia],velnames[ib]]}

def run(start,cap=20000):
    ps=[P(start[0].pos,start[0].vel),P(start[1].pos,start[1].vel)]
    seen={statekey(ps):0}; total=Z; events=[]
    for step in range(1,cap+1):
        nb=next_batch(ps)
        if nb is None: return {'status':'NO_EVENT','steps':step-1,'T':total,'events':events}
        batch,status=nb; e=batch[0]
        advance(ps,e.t); total=total+e.t
        rec={'step':step,'kind':e.kind,'face':e.face,'wall':e.walls,'dt':e.t.wire(),'T':total.wire()}
        events.append(rec)
        if status not in ('REGULAR','INDEPENDENT_WALL_BATCH'): return {'status':status,'steps':step,'T':total,'events':events,'batch':[x.kind for x in batch]}
        # independent wall hits commute; resolve all events in the batch.
        for ee in batch: resolve(ps,ee)
        key=statekey(ps)
        if key in seen:
            return {'status':'RETURN','steps':step,'preperiod':seen[key],'period_events':step-seen[key],'T':total,'cycle_T':total, 'events':events}
        seen[key]=step
    return {'status':'CAP','steps':cap,'T':total,'events':events}

def main():
    results=[]; counts={}; regular=[]
    for a,b in combinations(range(4),2):
      for ia,ib in product(range(4),repeat=2):
        r=run([P(sites[a],vels[ia]),P(sites[b],vels[ib])])
        r['start']=raw_label(a,b,ia,ib)
        # make Q values serializable
        r['T']=r['T'].wire()
        if 'cycle_T' in r: r['cycle_T']=r['cycle_T'].wire()
        results.append(r); counts[r['status']]=counts.get(r['status'],0)+1
        if r['status']=='RETURN': regular.append(r)
    # write witnesses longest return and first terminal each
    maxr=max(regular,key=lambda r:r['steps']) if regular else None
    out={'model':{'polygon':'regular dodecagon','edge':'1/2','apothem':apothem.wire(),'cell_side_D':D.wire(),'cardinal_width':'D/2','field':'Q(sqrt(3)) subset Q(sqrt(2),sqrt(3),sqrt(6))','container':'2x2 cells'},'raw_starts':len(results),'counts':counts,'max_regular_events':maxr['steps'] if maxr else None,'longest_regular_start':maxr['start'] if maxr else None,'longest_regular_cycle_T':maxr.get('cycle_T') if maxr else None,'results':results}
    os.makedirs(os.path.dirname(__file__),exist_ok=True)
    with open(os.path.join(os.path.dirname(__file__),'atlas.json'),'w') as f: json.dump(out,f,indent=2)
    with open(os.path.join(os.path.dirname(__file__),'SUMMARY.md'),'w') as f:
      f.write('# Exact 2×2 dodecagon atlas\n\n')
      f.write(f"Raw starts: {len(results)}\n\n")
      f.write('## Outcomes\n\n')
      for k in sorted(counts): f.write(f'- {k}: {counts[k]}\n')
      if maxr:
       f.write(f"\nLongest regular-only trajectory: {maxr['steps']} events; start {maxr['start']}; T={maxr['cycle_T']}\n")
      f.write('\nAll arithmetic is exact Q(sqrt(3)). Pair corners and every simultaneous batch are terminal classifications.\n')
    print(json.dumps({'counts':counts,'longest':None if not maxr else {'steps':maxr['steps'],'start':maxr['start'],'T':maxr['cycle_T']}} ,indent=2))
if __name__=='__main__': main()
