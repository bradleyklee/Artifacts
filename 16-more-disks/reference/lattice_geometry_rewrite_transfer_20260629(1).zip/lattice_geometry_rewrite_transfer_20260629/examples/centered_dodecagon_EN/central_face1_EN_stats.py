import sys,json
sys.path.insert(0,'/mnt/data/dodecagon_2x2')
import dodecagon_2x2 as m

face=1
n=m.normals[face][1]
# A at -a n with incoming E; B at +a n with incoming N.
ps=[m.P(n.scale(-m.apothem),m.vels[0]),m.P(n.scale(m.apothem),m.vels[2])]
m.resolve(ps,m.Event(m.Z,'pair',0,1,face,()))

def statsq(z):
    vals=[z.a,z.b]
    return max(abs(v.numerator) for v in vals), max(v.denominator for v in vals)
def allstats(ps,total):
    vals=[ps[0].pos.x,ps[0].pos.y,ps[1].pos.x,ps[1].pos.y]
    vel=[ps[0].vel.x,ps[0].vel.y,ps[1].vel.x,ps[1].vel.y]
    tm=[total]
    def agg(xs): return max(statsq(z)[0] for z in xs), max(statsq(z)[1] for z in xs)
    return {'pos_num':agg(vals)[0],'pos_den':agg(vals)[1],'vel_num':agg(vel)[0],'vel_den':agg(vel)[1],'time_num':agg(tm)[0],'time_den':agg(tm)[1]}

seen={m.statekey(ps):0}; total=m.Z; faces=[]; snaps=[]
for step in range(1,501):
    nb=m.next_batch(ps)
    batch,status=nb
    e=batch[0]
    m.advance(ps,e.t); total=total+e.t
    if status not in ('REGULAR','INDEPENDENT_WALL_BATCH'):
      print(json.dumps({'status':status,'step':step,'T':total.wire(),'stats':allstats(ps,total),'faces':faces},indent=2));break
    for ee in batch: m.resolve(ps,ee)
    if e.kind=='pair': faces.append(e.face)
    if step in [1,2,3,5,10,20,50,100,200,300,400,500]:
      snaps.append({'step':step,'T':total.wire(),'stats':allstats(ps,total),'pair_faces':sorted(set(faces)),'n_pair':len(faces)})
    key=m.statekey(ps)
    if key in seen:
      print(json.dumps({'status':'RETURN','step':step,'pre':seen[key],'T':total.wire(),'stats':allstats(ps,total),'faces':faces,'snaps':snaps},indent=2));break
    seen[key]=step
else:
    print(json.dumps({'status':'CAP','step':500,'T':total.wire(),'stats':allstats(ps,total),'pair_faces':sorted(set(faces)),'n_pair':len(faces),'snaps':snaps},indent=2))
