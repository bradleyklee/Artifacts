import sys, json, math, statistics
from collections import Counter
sys.path.insert(0,'/mnt/data/dodecagon_2x2')
import dodecagon_2x2 as m

FACE, IA, IB, CAP = 1, 0, 2, 12000 # E,N
n=m.normals[FACE][1]
ps=[m.P(n.scale(-m.apothem),m.vels[IA]),m.P(n.scale(m.apothem),m.vels[IB])]
m.resolve(ps,m.Event(m.Z,'pair',0,1,FACE,()))
seen={m.statekey(ps):0}; faces=[FACE]; total=m.Z
logs=[]
for step in range(1,CAP+1):
    nb=m.next_batch(ps)
    if nb is None: status='NO_EVENT'; break
    batch,status0=nb; e=batch[0]
    m.advance(ps,e.t); total=total+e.t
    if status0 not in ('REGULAR','INDEPENDENT_WALL_BATCH'):
        status=status0; break
    for ee in batch: m.resolve(ps,ee)
    if e.kind=='pair': faces.append(e.face)
    key=m.statekey(ps)
    if key in seen:
        status='RETURN'; break
    seen[key]=step
else:
    status='CAP'; step=CAP
word=''.join(str(f%3) for f in faces)

def chi_uniform(counter, k, n):
    exp=n/k
    return sum((counter.get(i,0)-exp)**2/exp for i in range(k))

def runs(word):
    rs=[]
    if not word:return rs
    last=word[0]; c=1
    for x in word[1:]:
        if x==last:c+=1
        else:rs.append((last,c));last=x;c=1
    rs.append((last,c));return rs

counts=Counter(map(int,word))
pairs=Counter(word[i:i+2] for i in range(len(word)-1))
triples=Counter(word[i:i+3] for i in range(len(word)-2))
# lag matches vs independent 1/3
lags={}
for lag in [1,2,3,4,5,10,20,50,100]:
    if lag < len(word):
        mcnt=sum(word[i]==word[i+lag] for i in range(len(word)-lag))
        n=len(word)-lag
        lags[lag]={'matches':mcnt,'n':n,'rate':mcnt/n,'excess':mcnt/n-1/3}
rs=runs(word)
runlens=Counter(l for _,l in rs)
# Empirical entropy estimates
H1=-sum((c/len(word))*math.log2(c/len(word)) for c in counts.values())
H2=-sum((c/(len(word)-1))*math.log2(c/(len(word)-1)) for c in pairs.values())
# conditional H next | previous
Hcond=H2-H1
# Lempel-Ziv 76 phrase count simplistic
# parsing into shortest unseen phrase
seenphr=set();i=0;phr=[]
while i<len(word):
    j=i+1
    while j<=len(word) and word[i:j] in seenphr: j+=1
    phr.append(word[i:j]); seenphr.add(word[i:j]); i=j
# collect current coefficient bits
vals=[]
for p in ps:
  for z in (p.pos.x,p.pos.y,p.vel.x,p.vel.y):
    vals += [z.a.numerator,z.a.denominator,z.b.numerator,z.b.denominator]
max_num_bits=max(abs(x).bit_length() for x in vals)
max_den_bits=max(x.bit_length() for x in vals if x>0)
report={
 'seed':{'face':FACE,'face_mod3':FACE%3,'incoming':['E','N'],'box':'4 cardinal widths','field':'Q(sqrt3)'},
 'event_cap':CAP,'status':status,'events_completed':step,'pair_collisions':len(faces),'ternary_word':word,
 'counts':{str(k):counts[k] for k in range(3)},
 'counts_chi2_uniform':chi_uniform(counts,3,len(word)),
 'pair_counts':dict(sorted(pairs.items())),
 'pair_chi2_uniform':chi_uniform({int(k[0])*3+int(k[1]):v for k,v in pairs.items()},9,len(word)-1),
 'triple_distinct':len(triples),'triple_total':len(word)-2,
 'H1_bits':H1,'H2_joint_bits':H2,'conditional_entropy_bits':Hcond,
 'lags':lags,
 'max_run_length':max(l for _,l in rs),'run_length_counts':dict(sorted(runlens.items())),
 'lz76_phrase_count':len(phr),
 'max_integer_numerator_bits':max_num_bits,'max_integer_denominator_bits':max_den_bits,
 'T':total.wire(),
}
open('/mnt/data/central_dodecagon_EN_12000_pairs_stats.json','w').write(json.dumps(report,indent=2))
open('/mnt/data/central_dodecagon_EN_12000_ternary.txt','w').write(','.join(word)+'\n')
print(json.dumps({k:report[k] for k in ['status','events_completed','pair_collisions','counts','counts_chi2_uniform','pair_chi2_uniform','H1_bits','conditional_entropy_bits','triple_distinct','max_run_length','lz76_phrase_count','max_integer_denominator_bits']},indent=2))
