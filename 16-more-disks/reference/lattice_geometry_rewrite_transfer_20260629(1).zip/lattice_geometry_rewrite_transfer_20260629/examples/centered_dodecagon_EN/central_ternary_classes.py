#!/usr/bin/env python3
import sys,json
from collections import Counter
sys.path.insert(0,'/mnt/data/dodecagon_2x2')
import dodecagon_2x2 as m

CAP=500
# Representatives of all three facet-label classes mod 3.
FACES=[0,1,2]

def qwire(z): return z.wire()

def run_central(face, ia, ib, cap=CAP):
    n=m.normals[face][1]
    vinA=m.vels[ia]; vinB=m.vels[ib]
    g=m.dot(n,vinB-vinA)
    if g.sign()>=0: return None
    # Left limit of collision: A=-a n, B=+a n, then resolve at t=0.
    ps=[m.P(n.scale(-m.apothem),vinA),m.P(n.scale(m.apothem),vinB)]
    m.resolve(ps,m.Event(m.Z,'pair',0,1,face,()))
    seen={m.statekey(ps):0}; total=m.Z
    pair_faces=[face]                 # Include prescribed central collision.
    all_events=[{'step':0,'kind':'pair','face':face,'wall':[]}]
    for step in range(1,cap+1):
        nb=m.next_batch(ps)
        if nb is None:
            return {'status':'NO_EVENT','steps':step-1,'T':qwire(total),'pair_faces':pair_faces,'events':all_events}
        batch,status=nb; e=batch[0]
        m.advance(ps,e.t); total=total+e.t
        all_events.append({'step':step,'kind':e.kind,'face':e.face,'wall':list(e.walls),
                           'batch':[{'kind':x.kind,'face':x.face,'wall':list(x.walls),'i':x.i,'j':x.j} for x in batch]})
        if status not in ('REGULAR','INDEPENDENT_WALL_BATCH'):
            return {'status':status,'steps':step,'T':qwire(total),'pair_faces':pair_faces,'events':all_events}
        for ee in batch: m.resolve(ps,ee)
        if e.kind=='pair': pair_faces.append(e.face)
        key=m.statekey(ps)
        if key in seen:
            return {'status':'RETURN','steps':step,'preperiod':seen[key], 'period_events':step-seen[key],
                    'T':qwire(total),'pair_faces':pair_faces,'events':all_events}
        seen[key]=step
    return {'status':'CAP','steps':cap,'T':qwire(total),'pair_faces':pair_faces,'events':all_events}

out=[]
for face in FACES:
    n=m.normals[face][1]
    for ia,va in enumerate(m.vels):
        for ib,vb in enumerate(m.vels):
            g=m.dot(n,vb-va)
            if g.sign()>=0: continue
            r=run_central(face,ia,ib)
            r.update({
                'face':face,
                'face_mod3':face%3,
                'incoming':[m.velnames[ia],m.velnames[ib]],
                'g':qwire(g),
                'ternary': ''.join(str(k%3) for k in r['pair_faces']),
                'pair_count':len(r['pair_faces']),
            })
            out.append(r)

counts=Counter(r['status'] for r in out)
long=[r for r in out if r['status']=='CAP']
summary={
  'model':'central collision at t=0; all relative-closing ordered NSEW pairs; exact Q(sqrt3); face reps 0,1,2 for classes mod 3',
  'cap_events':CAP,
  'faces':FACES,
  'cases':out,
  'counts':dict(counts),
  'long_runners':[{k:r[k] for k in ['face','face_mod3','incoming','status','steps','pair_count','ternary','T']} for r in long]
}
with open('/mnt/data/dodecagon_2x2/central_ternary_classes_500.json','w') as f: json.dump(summary,f,indent=2)
print('counts',dict(counts))
for r in out:
 print(r['face'],r['incoming'],r['status'],'steps',r['steps'],'pairs',r['pair_count'],'word',r['ternary'])
