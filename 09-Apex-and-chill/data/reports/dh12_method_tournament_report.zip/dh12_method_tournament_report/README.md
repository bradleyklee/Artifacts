# DH12 target-5 method tournament report

Current target-certified Apex remains **852 cells / depth 60 / CLOSED_CHILL**. No tested method produced >852 in this batch.

## Scoreboard
| method | best cells | depth | notes |
|---|---:|---:|---|
| t5_signpost_diff_24 | 852 | 60 | trials=18 |
| t5_signpost_diff_24 | 852 | 59 | trials=18 |
| t5_all_accept_44 | 852 | 58 | trials=15 |
| t5_signpost_accept_36 | 852 | 58 | trials=18 |
| t5_signpost_accept_36 | 852 | 57 | trials=18 |
| diff_deep_48 | 852 | 56 | gt852=0, ge852=9, trials=10 |
| blank_break_64 | 852 | 55 | gt852=0, ge852=5, trials=10 |
| all_accept_88 | 852 | 55 | gt852=0, ge852=3, trials=8 |
| blank_break_fast_96 | 852 | 55 | gt852=0, ge852=2, trials=4 |
| all_accept_fast_128 | 852 | 55 | gt852=0, ge852=2, trials=3 |
| chaos_fast_120 | 834 | 57 | gt852=0, ge852=0, trials=3 |
| volatile_rarest_fast | 816 | 53 | gt852=0, ge852=0, trials=3 |
| ridge_anti_b_72 | 804 | 57 | gt852=0, ge852=0, trials=10 |
| late_destructive_12 | 696 | 47 | gt852=0, ge852=0, trials=10 |
| wall_accept_12 | 42 | 4 | gt852=0, ge852=0, trials=18 |
| wall_accept_32 | 42 | 4 | gt852=0, ge852=0, trials=14 |

## Method conclusions
- **Signpost/differential push** is the only family that reliably returns 852/depth60; it is alive but currently saturated.
- **Accept-heavy / blank-break** can reproduce 852 but tends to lower depth; no >852 yet.
- **Broad anti-mate / ridge anti-b** makes 800-ish variants, but not high plateau improvements.
- **Volatile rarest / chaos** creates lower alternative basins around 816–834, not improvements.
- **Direct final-wall accept** is actively bad: it dies around 42 cells. Those wall blanks are probably context-overloaded and cannot simply be accepted globally.
- **Late-destructive edits** are also bad in tested form: best fell to 696/depth47 and larger versions became computationally expensive.

## Next recommendation
The next serious method should not be more global genome twiddling. It should be a context-sensitive or local exception mechanism: sparse radius-2/wall exception, or online beam search that only opens wall rules in the correct late context.