#!/usr/bin/env python3
import json, hashlib
from pathlib import Path
from lxml import etree
import cairosvg, fitz

NS='http://www.w3.org/2000/svg'
def E(tag): return f'{{{NS}}}{tag}'

def add_text(parent, x, y, txt, **attrs):
    el = etree.SubElement(parent, E('text'))
    el.attrib['x'] = str(x)
    el.attrib['y'] = str(y)
    for k,v in attrs.items(): el.attrib[k.replace('_','-')] = str(v)
    el.text = txt
    return el

def wrap_csv(seq, max_chars):
    items=[str(x) for x in seq]
    lines=[]; cur=''
    for it in items:
        part = it if not cur else ', ' + it
        if len(cur) + len(part) <= max_chars:
            cur += part
        else:
            lines.append(cur)
            cur = it
    if cur: lines.append(cur)
    return lines

BASE_SVG=Path('/mnt/data/apex_and_chill_page13_v87_plateau_preview.svg')
BASE_PDF=Path('/mnt/data/apex_and_chill_page13_v87_plateau_preview.pdf')
BASE_PAYLOAD=Path('/mnt/data/apex852_pdf_payload_v87_reduced_certificate.json')
STYLE_JSON=Path('/mnt/data/apex_v43/data/pseudocode_style_object_v40.json')
SVG_OUT=Path('/mnt/data/apex_and_chill_page13_v88_bottom_spacing.svg')
PDF_TMP=Path('/mnt/data/apex_and_chill_page13_v88_bottom_spacing_tmp.pdf')
PDF_OUT=Path('/mnt/data/apex_and_chill_page13_v88_bottom_spacing.pdf')
PAYLOAD_OUT=Path('/mnt/data/apex852_pdf_payload_v88_reduced_certificate.json')
REPORT_OUT=Path('/mnt/data/apex_and_chill_page13_v88_bottom_spacing_report.json')

root=etree.fromstring(BASE_SVG.read_bytes())
payload=json.loads(BASE_PAYLOAD.read_text())
payload['artifact']='apex852_pdf_payload_v88_reduced_certificate'
PAYLOAD_OUT.write_text(json.dumps(payload, indent=2)+'\n')
payload_sha=hashlib.sha256(PAYLOAD_OUT.read_bytes()).hexdigest()

panel=root.xpath('//*[local-name()="svg" and @id="rules_growth_panel_v79"]')[0]
for ch in list(panel):
    panel.remove(ch)

cream='#fbfaf7'; black='#181513'; gray='#817a71'; border='#b8b1a6'
# slightly taller-feeling internal layout; nested svg geometry unchanged
etree.SubElement(panel, E('rect'), {'x':'0','y':'0','width':'575','height':'72','fill':cream,'stroke':'none'})
split_x=312
etree.SubElement(panel, E('line'), {'x1':str(split_x),'y1':'6','x2':str(split_x),'y2':'70','stroke':border,'stroke-width':'0.7'})

# left column with a little more title gap
add_text(panel, 4, 9, 'Hints:', font_family='DejaVu Serif', font_size='8.8', fill=black)
acc=sorted(payload['accept_rules'], key=lambda r: r['matrix_index'])
rule_texts=[f"{r['matrix_index']:03d} → {r['output_type']}" for r in acc]
cols=6; rows=8
x0=4; y0=21.0; col_w=50.0; row_h=6.25
for i,txt in enumerate(rule_texts):
    c=i//rows; r=i%rows
    add_text(panel, x0+c*col_w, y0+r*row_h, txt, font_family='DejaVu Sans Mono, DejaVu Sans, sans-serif', font_size='5.85', fill=black)

# right column with tighter subtitle spacing and more float above text
add_text(panel, 322, 9, 'Growth counts', font_family='DejaVu Serif', font_size='8.95', fill=black)
add_text(panel, 391, 9, '(divided by six)', font_family='DejaVu Serif', font_size='8.95', fill=gray)
preview_a=payload['growth_counts'].get('a_sequence_plateau_preview', payload['growth_counts']['a_sequence'])
preview_d=payload['growth_counts'].get('first_differences_plateau_preview', payload['growth_counts']['first_differences'])
a_lines=wrap_csv(preview_a, 74)
d_lines=wrap_csv(preview_d, 78)
add_text(panel, 322, 25.0, 'a:', font_family='Courier Prime, Courier New, monospace', font_size='6.45', fill=black)
for i,line in enumerate(a_lines[:3]):
    add_text(panel, 335, 25.0+i*7.2, line, font_family='Courier Prime, Courier New, monospace', font_size='5.55', fill=black)
add_text(panel, 322, 51.0, 'Δ:', font_family='Courier Prime, Courier New, monospace', font_size='6.45', fill=black)
for i,line in enumerate(d_lines[:3]):
    add_text(panel, 335, 51.0+i*7.2, line, font_family='Courier Prime, Courier New, monospace', font_size='5.55', fill=black)

# metadata
metas=root.xpath('//*[local-name()="metadata"]')
if metas:
    try: meta=json.loads(metas[0].text)
    except Exception: meta={}
    meta.update({
        'variant':'v88_bottom_spacing',
        'payload_embedded':PAYLOAD_OUT.name,
        'payload_sha256':payload_sha,
        'bottom_panel':'two-column layout retained; title gap increased; Growth counts subtitle tightened; plateau preview retained in payload and visible counts panel',
    })
    metas[0].text=json.dumps(meta, sort_keys=True)

SVG_OUT.write_bytes(etree.tostring(root, encoding='utf-8', xml_declaration=False))

cairosvg.svg2pdf(url=str(SVG_OUT), write_to=str(PDF_TMP))
base=fitz.open(BASE_PDF)
out=fitz.open(PDF_TMP)
for pno in range(min(len(base), len(out))):
    for link in base[pno].get_links():
        if link.get('kind')==fitz.LINK_URI:
            out[pno].insert_link({'kind':fitz.LINK_URI, 'from':link['from'], 'uri':link['uri']})
out.embfile_add(PAYLOAD_OUT.name, PAYLOAD_OUT.read_bytes(), filename=PAYLOAD_OUT.name, ufilename=PAYLOAD_OUT.name, desc='reduced finite-certificate payload v88 with plateau preview')
out.embfile_add(STYLE_JSON.name, STYLE_JSON.read_bytes(), filename=STYLE_JSON.name, ufilename=STYLE_JSON.name, desc='pseudocode style object v40')
out.save(PDF_OUT)
out.close(); base.close()

pdf=fitz.open(PDF_OUT)
report={
  'artifact':'apex_and_chill_page13_v88_bottom_spacing',
  'svg':str(SVG_OUT),
  'pdf':str(PDF_OUT),
  'payload':str(PAYLOAD_OUT),
  'title_positions':{'hints_y':9,'rules_start_y':21.0,'growth_title_x':322,'growth_gray_x':391,'counts_start_y':25.0},
  'pdf_link_uris':[link['uri'] for link in pdf[0].get_links() if link.get('kind')==fitz.LINK_URI],
  'pdf_embedded_files':[pdf.embfile_info(i)['filename'] for i in range(pdf.embfile_count())],
  'image_xobjects':len(pdf[0].get_images(full=True)),
}
REPORT_OUT.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
