#!/usr/bin/env python3
"""
Derive a finite-growth JSON certificate from visible SVG geometry only.
This does not read the embedded payload, the accept list, or the existing matrix
statuses to decide rules. It extracts:
  - main pattern state from visible hexes/ports
  - P7 templates from visible thumbnails
then enumerates P7 x 64 masks, canonicalizes, and forces evolution along the
visible main pattern to mark the accept/reject rules actually needed for the
finite chiller.
"""
import json, math, hashlib
from pathlib import Path
from lxml import etree
import sys
sys.path.append('/mnt/data')
import visible_pdf_scrape_rederive_v44 as v
# Reuse SVG geometry extraction from v59; no payload data is imported.
import importlib.util
spec = importlib.util.spec_from_file_location('ex59','/mnt/data/apex_v58_visible_svg_extract_verify_v59.py')
ex59 = importlib.util.module_from_spec(spec); spec.loader.exec_module(ex59)

SVG_IN = Path('/mnt/data/apex_and_chill_page13_v58_matrix_p7_restore.svg')
OUT_LITERAL = Path('/mnt/data/apex_v58_visible_svg_growth_derived_literal_p7_v60.json')
OUT_REFLECTED = Path('/mnt/data/apex_v58_visible_svg_growth_derived_slot_reflect_p7_v60.json')
REPORT_OUT = Path('/mnt/data/apex_v58_visible_svg_image_to_growth_json_report_v60.json')


def slot_reflect_templates(templates):
    out=[]
    for t in templates:
        slots=[None]*6
        for d,st in enumerate(t['slots']):
            slots[(-d)%6] = st
        out.append({'rep_index': t['rep_index'], 'center': t['center'], 'slots': slots})
    return out


def force_rules_from_target(matrix_rows, target_state, max_steps=10000):
    key_to_row = {row['canonical_neighbor_key']: row for row in matrix_rows}
    # target-visible seed around the blocked center
    axiom = {d: target_state.get(d) for d in v.DIRS_AXIAL}
    if any(x is None for x in axiom.values()):
        return {'ok': False, 'reason': 'missing_axiom', 'axiom': {str(k): val for k,val in axiom.items()}}
    state = dict(axiom)
    blocked = {(0,0)}
    accept = {}
    reject = {}
    history=[]
    unknown=[]
    conflicts=[]
    for step in range(max_steps):
        births={}
        step_accept=0
        step_reject=0
        unknown=[]
        conflicts=[]
        for q,r in sorted(v.frontier(state, blocked)):
            raw=tuple(state.get((q+dq, r+dr), '*') for dq,dr in v.DIRS_AXIAL)
            key, rot = v.canonicalize(raw)
            row = key_to_row.get(key)
            if row is None:
                unknown.append({'cell':[q,r], 'raw_key':list(raw), 'canonical_key':list(key), 'rotation_k':rot})
                continue
            idx = row['matrix_index']
            if (q,r) in target_state:
                target = target_state[(q,r)]
                canonical_output = v.rotate_state(target, rot)
                old = accept.get(key)
                if old is not None and old['output'] != canonical_output:
                    conflicts.append({'kind':'accept_output_conflict','cell':[q,r],'idx':idx,'old':old['output'],'new':canonical_output})
                    continue
                old_rej = reject.get(key)
                if old_rej is not None:
                    conflicts.append({'kind':'accept_reject_conflict','cell':[q,r],'idx':idx})
                    continue
                accept[key] = {'matrix_index': idx, 'canonical_neighbor_key': '|'.join(key), 'output': canonical_output, 'output_type': canonical_output.split('.')[0]}
                births[(q,r)] = target
                step_accept += 1
            else:
                old_acc = accept.get(key)
                if old_acc is not None:
                    conflicts.append({'kind':'reject_accept_conflict','cell':[q,r],'idx':idx})
                    continue
                reject[key] = {'matrix_index': idx, 'canonical_neighbor_key': '|'.join(key)}
                step_reject += 1
        history.append({'t': step, 'births': len(births), 'placed': len(state)+len(births), 'frontier_accept_events': step_accept, 'frontier_reject_events': step_reject, 'unknown_frontier': len(unknown), 'conflicts': len(conflicts)})
        if unknown or conflicts:
            return {'ok': False, 'reason':'unknown_or_conflict', 'history':history, 'unknown':unknown[:20], 'conflicts':conflicts[:20]}
        if not births:
            break
        state.update(births)
    else:
        return {'ok': False, 'reason':'max_steps_exceeded', 'history':history}
    # Independent replay with the derived accept/reject sets.
    acc_map = {k: rec['output'] for k,rec in accept.items()}
    rej_set = set(reject.keys())
    replay_state, replay_history, replay_unknown = v.replay(acc_map, rej_set, axiom, max_steps=10000)
    cmp = v.compare_states(replay_state, target_state)
    accept_list = sorted(accept.values(), key=lambda r:r['matrix_index'])
    reject_list = sorted(reject.values(), key=lambda r:r['matrix_index'])
    return {
        'ok': True,
        'matrix_rows': len(matrix_rows),
        'accept_rules': accept_list,
        'reject_rules': reject_list,
        'seed_axiom': {f'{q},{r}': st for (q,r),st in sorted(axiom.items())},
        'history': history,
        'verification': {
            'final_cells': len(replay_state),
            'terminal_step': len(replay_history)-1,
            'terminal_births': replay_history[-1]['births'],
            'terminal_unknown_frontier': replay_history[-1]['unknown_frontier'],
            'missing_vs_visible_main': len(cmp['missing']),
            'extra_vs_visible_main': len(cmp['extra']),
            'wrong_vs_visible_main': len(cmp['wrong']),
        },
    }


def make_payload(kind, templates, result, source_counts):
    return {
        'artifact': f'apex_v58_visible_svg_image_to_growth_json_v60_{kind}',
        'source_svg': str(SVG_IN),
        'derivation_source': 'visible SVG geometry only: main pattern + P7 thumbnails; rules forced by evolution along visible main pattern',
        'embedded_payload_used_for_derivation': False,
        'existing_matrix_status_used_for_derivation': False,
        'existing_accept_list_used_for_derivation': False,
        'p7_interpretation': kind,
        'source_counts': source_counts,
        'p7_templates': [{'rep_index':t['rep_index'], 'center':t['center'], 'slots':t['slots']} for t in templates],
        'matrix_unique_contexts': result.get('matrix_rows'),
        'seed_axiom': result.get('seed_axiom'),
        'accept_rules': result.get('accept_rules'),
        'reject_rules': result.get('reject_rules'),
        'verification': result.get('verification'),
        'history_tail': result.get('history', [])[-5:],
    }


def main():
    parser=etree.XMLParser(recover=True, huge_tree=True, remove_blank_text=False)
    root=etree.fromstring(SVG_IN.read_bytes(), parser)
    target_state, main_geom, main_report = ex59.extract_main_state(root)
    visible_templates = ex59.extract_p7_templates(root)
    literal_rows = v.build_matrix_from_p7([{'rep_index':t['rep_index'], 'center':t['center'], 'slots':t['slots']} for t in visible_templates])
    reflected_templates = slot_reflect_templates(visible_templates)
    reflected_rows = v.build_matrix_from_p7(reflected_templates)
    literal_result = force_rules_from_target(literal_rows, target_state)
    reflected_result = force_rules_from_target(reflected_rows, target_state)
    source_counts={'visible_main_cells': len(target_state), 'visible_p7_templates': len(visible_templates)}
    literal_payload = make_payload('literal_visible_p7_axes', visible_templates, literal_result, source_counts)
    reflected_payload = make_payload('slot_reflect_visible_p7_axes', reflected_templates, reflected_result, source_counts)
    OUT_LITERAL.write_text(json.dumps(literal_payload, indent=2)+'\n')
    OUT_REFLECTED.write_text(json.dumps(reflected_payload, indent=2)+'\n')
    report={
        'artifact':'apex_v58_visible_svg_image_to_growth_json_report_v60',
        'source_svg': str(SVG_IN),
        'embedded_payload_used_for_derivation': False,
        'main_extraction': main_report,
        'literal_visible_p7_axes': {
            'matrix_rows': len(literal_rows),
            'ok': literal_result.get('ok'),
            'accept_rules': len(literal_result.get('accept_rules',[])) if literal_result.get('ok') else None,
            'reject_rules': len(literal_result.get('reject_rules',[])) if literal_result.get('ok') else None,
            'verification': literal_result.get('verification'),
            'failure': None if literal_result.get('ok') else {k:literal_result.get(k) for k in ['reason','unknown','conflicts']},
        },
        'slot_reflect_visible_p7_axes': {
            'matrix_rows': len(reflected_rows),
            'ok': reflected_result.get('ok'),
            'accept_rules': len(reflected_result.get('accept_rules',[])) if reflected_result.get('ok') else None,
            'reject_rules': len(reflected_result.get('reject_rules',[])) if reflected_result.get('ok') else None,
            'verification': reflected_result.get('verification'),
            'failure': None if reflected_result.get('ok') else {k:reflected_result.get(k) for k in ['reason','unknown','conflicts']},
        },
        'diagnosis': 'literal P7 axes are the non-circular test; slot_reflect mode is a salvage/convention transform. A final self-checking page should make the literal mode pass, not require the salvage transform.',
        'outputs': {'literal_payload': str(OUT_LITERAL), 'slot_reflect_payload': str(OUT_REFLECTED)},
        'sha256': {
            'literal_payload': hashlib.sha256(OUT_LITERAL.read_bytes()).hexdigest(),
            'slot_reflect_payload': hashlib.sha256(OUT_REFLECTED.read_bytes()).hexdigest(),
        }
    }
    REPORT_OUT.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
