#!/usr/bin/env python3
import json, hashlib
from pathlib import Path
from lxml import etree
import cairosvg, fitz

BASE_SVG=Path('/mnt/data/apex_and_chill_page13_v82_hints_rules_no_regression.svg')
BASE_PDF=Path('/mnt/data/apex_and_chill_page13_v82_hints_rules_no_regression.pdf')
BASE_PAYLOAD=Path('/mnt/data/apex852_pdf_payload_v82_reduced_certificate.json')
STYLE_JSON=Path('/mnt/data/apex_v43/data/pseudocode_style_object_v40.json')
SVG_OUT=Path('/mnt/data/apex_and_chill_page13_v83_hints_rules_real_arrows.svg')
PDF_TMP=Path('/mnt/data/apex_and_chill_page13_v83_hints_rules_real_arrows_tmp.pdf')
PDF_OUT=Path('/mnt/data/apex_and_chill_page13_v83_hints_rules_real_arrows.pdf')
PAYLOAD_OUT=Path('/mnt/data/apex852_pdf_payload_v83_reduced_certificate.json')
REPORT_OUT=Path('/mnt/data/apex_and_chill_page13_v83_hints_rules_real_arrows_report.json')

parser=etree.XMLParser(remove_blank_text=False)
root=etree.fromstring(BASE_SVG.read_bytes(), parser)
payload=json.loads(BASE_PAYLOAD.read_text())
payload['artifact']='apex852_pdf_payload_v83_reduced_certificate'
PAYLOAD_OUT.write_text(json.dumps(payload, indent=2)+'\n')
payload_sha=hashlib.sha256(PAYLOAD_OUT.read_bytes()).hexdigest()

# Force the Hints rule entries into a font with a real right-arrow glyph.
# This avoids Courier fallback showing a missing glyph box.
rule_texts=[]
for el in root.xpath('//*[local-name()="svg" and @id="rules_growth_panel_v79"]//*[local-name()="text"]'):
    txt=''.join(el.itertext()).strip()
    if '→' in txt and any(txt.endswith(suffix) for suffix in ('→H','→D')):
        el.attrib['font-family']='DejaVu Sans Mono, DejaVu Sans, sans-serif'
        el.attrib['font-size']='5.75'
        el.attrib['fill']='#181513'
        rule_texts.append(txt)

metas=root.xpath('//*[local-name()="metadata"]')
if metas:
    try: meta=json.loads(metas[0].text)
    except Exception: meta={}
    meta.update({
        'variant':'v83_hints_rules_real_arrows',
        'payload_embedded':PAYLOAD_OUT.name,
        'payload_sha256':payload_sha,
        'rule_arrow_font_fix':'Hints rule entries use DejaVu Sans Mono so U+2192 renders as a real arrow glyph.',
    })
    metas[0].text=json.dumps(meta, sort_keys=True)

SVG_OUT.write_bytes(etree.tostring(root, encoding='utf-8', xml_declaration=False))
cairosvg.svg2pdf(url=str(SVG_OUT), write_to=str(PDF_TMP))
base=fitz.open(BASE_PDF); out=fitz.open(PDF_TMP)
for pno in range(min(len(base), len(out))):
    for link in base[pno].get_links():
        if link.get('kind')==fitz.LINK_URI:
            out[pno].insert_link({'kind':fitz.LINK_URI,'from':link['from'],'uri':link['uri']})
out.embfile_add(PAYLOAD_OUT.name, PAYLOAD_OUT.read_bytes(), filename=PAYLOAD_OUT.name, ufilename=PAYLOAD_OUT.name, desc='reduced finite-certificate payload v83')
out.embfile_add(STYLE_JSON.name, STYLE_JSON.read_bytes(), filename=STYLE_JSON.name, ufilename=STYLE_JSON.name, desc='pseudocode style object v40')
out.save(PDF_OUT)
out.close(); base.close()

pdf=fitz.open(PDF_OUT)
report={
    'artifact':'apex_and_chill_page13_v83_hints_rules_real_arrows',
    'svg':str(SVG_OUT),
    'pdf':str(PDF_OUT),
    'payload':str(PAYLOAD_OUT),
    'rule_entries_fixed':len(rule_texts),
    'left_rule_grid':{'cols':8,'rows':6},
    'pdf_link_uris':[link['uri'] for link in pdf[0].get_links() if link.get('kind')==fitz.LINK_URI],
    'pdf_embedded_files':[pdf.embfile_info(i)['filename'] for i in range(pdf.embfile_count())],
    'image_xobjects':len(pdf[0].get_images(full=True)),
}
REPORT_OUT.write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
