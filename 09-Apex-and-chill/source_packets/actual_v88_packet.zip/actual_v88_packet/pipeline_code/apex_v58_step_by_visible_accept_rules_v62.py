#!/usr/bin/env python3
"""Step growth according to visible accept/reject markings in v58 SVG.
Diagnostic only; no embedded payload used for derivation.
"""
import json, hashlib, re, sys
from pathlib import Path
from lxml import etree
sys.path.append('/mnt/data')
import visible_pdf_scrape_rederive_v44 as v
import importlib.util
spec=importlib.util.spec_from_file_location('ex59','/mnt/data/apex_v58_visible_svg_extract_verify_v59.py')
ex59=importlib.util.module_from_spec(spec); spec.loader.exec_module(ex59)
spec60=importlib.util.spec_from_file_location('ex60','/mnt/data/apex_v58_visible_svg_image_to_growth_json_v60.py')
ex60=importlib.util.module_from_spec(spec60); spec60.loader.exec_module(ex60)
spec61=importlib.util.spec_from_file_location('ex61','/mnt/data/apex_v58_main_image_step_growth_v61.py')
ex61=importlib.util.module_from_spec(spec61); spec61.loader.exec_module(ex61)

SVG_IN=Path('/mnt/data/apex_and_chill_page13_v58_matrix_p7_restore.svg')
OUT=Path('/mnt/data/apex_v58_step_by_visible_accept_rules_v62.json')
REPORT=Path('/mnt/data/apex_v58_step_by_visible_accept_rules_v62_report.json')
BLUE='#2b4fc4'; MAGENTA='#c53aa5'
START_X=17.76; START_Y=4.84; PITCH=7.12

def norm_hex(s): return s.lower()

def extract_matrix_status(root):
    mat=root.xpath('//*[local-name()="svg" and @id="combined_rule_matrix_center0_modrot_v36"]')[0]
    status={}
    for el in mat.xpath('./*[local-name()="rect"]'):
        fill=norm_hex(el.attrib.get('fill',''))
        if fill not in {BLUE, MAGENTA, '#000000'}: continue
        try:
            x=float(el.attrib['x']); y=float(el.attrib['y']); w=float(el.attrib.get('width','0')); h=float(el.attrib.get('height','0'))
        except Exception: continue
        # ignore legend swatches, pad markers handled separately by width 6.76 but still grid located
        if not (0 <= x <= 150 and 0 <= y <= 220): continue
        col=round((x-START_X)/PITCH); row=round((y-START_Y)/PITCH)
        # pad black uses x-0.66/y-0.66 in v58; adjust
        if fill=='#000000':
            col=round((x+0.66-START_X)/PITCH); row=round((y+0.66-START_Y)/PITCH)
        if not (0 <= col < 18 and 0 <= row < 30): continue
        idx=row*18+col
        if fill==BLUE: status[idx]='accept'
        elif fill==MAGENTA: status[idx]='reject'
        elif fill=='#000000': status[idx]='pad'
    return status

def step_with_status(matrix_rows, status_by_idx, target_state, max_steps=1000):
    key_to_row={row['canonical_neighbor_key']: row for row in matrix_rows}
    axiom={d:target_state.get(d) for d in v.DIRS_AXIAL}
    state=dict(axiom); blocked={(0,0)}; outputs={}; accept_events=[]; history=[]
    if any(x is None for x in axiom.values()):
        return {'ok':False,'reason':'missing_axiom'}
    for t in range(max_steps):
        births={}; unknown=[]; conflicts=[]; rej=0; acc=0; blank=0
        for q,r in sorted(v.frontier(state, blocked)):
            raw=tuple(state.get((q+dq,r+dr),'*') for dq,dr in v.DIRS_AXIAL)
            key,rot=v.canonicalize(raw); row=key_to_row.get(key)
            if row is None:
                unknown.append({'cell':[q,r],'kind':'no_matrix_row','raw_key':list(raw),'canonical_key':list(key),'rotation_k':rot})
                continue
            idx=row['matrix_index']; status=status_by_idx.get(idx,'blank')
            if status=='accept':
                if (q,r) not in target_state:
                    conflicts.append({'kind':'accept_outside_target','cell':[q,r],'matrix_index':idx,'raw_key':list(raw),'canonical_key':list(key),'rotation_k':rot})
                    continue
                target=target_state[(q,r)]
                canonical_output=v.rotate_state(target, rot)
                old=outputs.get(key)
                if old is not None and old!=canonical_output:
                    conflicts.append({'kind':'accept_output_conflict','cell':[q,r],'matrix_index':idx,'old':old,'new':canonical_output,'target_output_at_cell':target})
                    continue
                outputs[key]=canonical_output
                births[(q,r)]=target; acc+=1
                accept_events.append({'step':t,'cell':[q,r],'matrix_index':idx,'raw_key':list(raw),'canonical_key':list(key),'rotation_k':rot,'target_output_at_cell':target,'canonical_output_image':canonical_output,'rule_image_ascii': '|'.join(key)+' -> '+canonical_output})
            elif status=='reject':
                rej+=1
            else:
                blank+=1
                unknown.append({'cell':[q,r],'kind':'blank_or_unmarked_matrix_row','matrix_index':idx,'status':status,'raw_key':list(raw),'canonical_key':list(key),'rotation_k':rot})
        history.append({'t':t,'births':len(births),'placed':len(state)+len(births),'accept_events':acc,'reject_events':rej,'blank_or_unknown_frontier':len(unknown),'conflicts':len(conflicts)})
        if unknown or conflicts:
            return {'ok':False,'reason':'blocked_at_frontier','history':history,'unknown':unknown[:20],'conflicts':conflicts[:20],'accept_events_so_far':accept_events,'accept_rule_images_so_far': sorted([{'canonical_neighbor_key':'|'.join(k),'output':out,'output_type':out.split('.')[0]} for k,out in outputs.items()], key=lambda r:r['canonical_neighbor_key'])}
        if not births: break
        state.update(births)
    acc_map={k:out for k,out in outputs.items()}
    # We do not have a reject set by key here; this is diagnostic.
    return {'ok':True,'history':history,'accept_events':accept_events,'accept_rule_images':sorted([{'canonical_neighbor_key':'|'.join(k),'output':out,'output_type':out.split('.')[0]} for k,out in outputs.items()], key=lambda r:r['canonical_neighbor_key'])}

def slot_reflect_templates(templates):
    out=[]
    for t in templates:
        slots=[None]*6
        for d,st in enumerate(t['slots']): slots[(-d)%6]=st
        out.append({'rep_index':t['rep_index'],'center':t['center'],'slots':slots})
    return out

def main():
    root=etree.fromstring(SVG_IN.read_bytes(), etree.XMLParser(recover=True, huge_tree=True, remove_blank_text=False))
    target, geom, main_report=ex59.extract_main_state(root)
    visible_templates=[{'rep_index':t['rep_index'],'center':t['center'],'slots':t['slots']} for t in ex59.extract_p7_templates(root)]
    main_templates, full_count=ex61.derive_p7_templates_from_main(target)
    status=extract_matrix_status(root)
    variants={
      'visible_p7_literal': v.build_matrix_from_p7(visible_templates),
      'visible_p7_slot_reflect': v.build_matrix_from_p7(slot_reflect_templates(visible_templates)),
      'main_full_p7_1513_diagnostic': v.build_matrix_from_p7(main_templates),
    }
    results={name: step_with_status(rows, status, target) | {'matrix_rows': len(rows)} for name,rows in variants.items()}
    out={'artifact':'apex_v58_step_by_visible_accept_rules_v62','source_svg':str(SVG_IN),'embedded_payload_used_for_derivation':False,'visible_main_report':main_report,'visible_matrix_status_counts':dict(__import__('collections').Counter(status.values())),'results':results}
    OUT.write_text(json.dumps(out, indent=2)+'\n')
    report={'artifact':'apex_v58_step_by_visible_accept_rules_v62_report','source_svg':str(SVG_IN),'visible_matrix_status_counts':dict(__import__('collections').Counter(status.values())),'summary':{name:{'ok':res.get('ok'),'matrix_rows':res.get('matrix_rows'),'reason':res.get('reason'),'history_head':res.get('history',[])[:3],'first_unknown':(res.get('unknown') or [None])[0],'first_conflict':(res.get('conflicts') or [None])[0],'accept_rule_images_so_far':len(res.get('accept_rule_images_so_far',res.get('accept_rule_images',[])))} for name,res in results.items()},'output_json':str(OUT),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest()}
    REPORT.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
if __name__=='__main__': main()
