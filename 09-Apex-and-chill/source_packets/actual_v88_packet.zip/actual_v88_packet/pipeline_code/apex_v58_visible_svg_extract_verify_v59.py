#!/usr/bin/env python3
"""
Visible SVG -> JSON -> replay verification for Apex 852 v58.

Derivation source is the visible vector geometry in the SVG only:
  - main pattern polygons + port lines
  - P7 thumbnail polygons + port lines
  - matrix grid colored rectangles
  - accept list visible text

Forbidden for derivation:
  - embedded PDF payload JSON
  - sidecar payload JSON
  - v49/v58 payload files

An optional oracle comparison can be performed after derivation, but is not used
in building the visible-derived payload.
"""
import json, math, re, hashlib
from pathlib import Path
from collections import Counter, defaultdict
from lxml import etree
import sys
sys.path.append('/mnt/data')
import visible_pdf_scrape_rederive_v44 as v

NS = 'http://www.w3.org/2000/svg'
def E(tag):
    return f'{{{NS}}}{tag}'

SVG_IN = Path('/mnt/data/apex_and_chill_page13_v58_matrix_p7_restore.svg')
DERIVED_PAYLOAD_OUT = Path('/mnt/data/apex_v58_visible_svg_derived_payload_v59.json')
REDUCED_PAYLOAD_OUT = Path('/mnt/data/apex_v58_visible_svg_derived_reduced_growth_payload_v59.json')
STATE_OUT = Path('/mnt/data/apex_v58_visible_svg_extracted_main_state_v59.json')
REPORT_OUT = Path('/mnt/data/apex_v58_visible_svg_extract_verify_report_v59.json')

# Rendering constants from the upstream SVG generator. These are geometry constants
# for interpreting visible vector positions, not rule/payload data.
MAIN_GROUP_ID = 'main_apex852_pattern_ccw_orientation_repair'
MATRIX_ID = 'combined_rule_matrix_center0_modrot_v36'
ACCEPT_LIST_ID = 'accept_rule_list_91_v36'
MAIN_R = 4.799
MAIN_GROUP_X = 46.0
MAIN_GROUP_Y = 142.0
VIEW_W = 382.0
VIEW_H = 322.0
SCALE_PDF_TO_SVG = 1.0 / 0.75
MAIN_DX = 6.2655029296875 * SCALE_PDF_TO_SVG
MAIN_DY = 5.425994873046875 * SCALE_PDF_TO_SVG
MAIN_ORIGIN_X = 177.75 * SCALE_PDF_TO_SVG - MAIN_GROUP_X
MAIN_ORIGIN_Y = 223.50 * SCALE_PDF_TO_SVG - MAIN_GROUP_Y
P7_SPACING = 11.172

COL_H = '#7ebe6f'
COL_D = '#e2c95f'
COL_BLOCKED = '#000000'
COL_ACCEPT = '#2b4fc4'
COL_REJECT = '#c53aa5'
COL_PAD = '#000000'

# Matrix geometry in its own nested SVG viewBox.
GRID_START_X = 17.76
GRID_START_Y = 4.84
GRID_PITCH = 7.12
GRID_W = 5.44
GRID_COLS = 18
GRID_ROWS = 30
GRID_MIN_X = 15.0
GRID_MAX_X = 146.0
GRID_MIN_Y = 3.0
GRID_MAX_Y = 219.0


def norm_hex_color(s):
    if s is None:
        return ''
    return s.strip().lower()


def polygon_centroid(poly):
    pts=[]
    for pair in poly.attrib['points'].replace(',', ' ').split():
        # This branch is not used because replacing commas destroys pairing; keep robust below.
        pass
    pts=[]
    for pair in poly.attrib['points'].split():
        x,y=map(float,pair.split(',')); pts.append((x,y))
    return sum(x for x,y in pts)/len(pts), sum(y for x,y in pts)/len(pts)


def polygon_radius(poly, cx, cy):
    pts=[]
    for pair in poly.attrib['points'].split():
        x,y=map(float,pair.split(',')); pts.append((x,y))
    return sum(math.hypot(x-cx, y-cy) for x,y in pts)/len(pts)


def fill_to_type(fill):
    c = norm_hex_color(fill)
    if c == COL_H:
        return 'H'
    if c == COL_D:
        return 'D'
    if c == COL_BLOCKED:
        return 'blocked'
    return None


def state_from_type_and_ports(typ, ports):
    if typ == 'blocked':
        return 'blocked'
    return v.physical_state_from_ports(typ, tuple(sorted(ports)))


def line_ports_for_center(group, cx, cy, tol=0.035):
    ports=[]
    for line in group.xpath('.//*[local-name()="line"]'):
        try:
            x1=float(line.attrib['x1']); y1=float(line.attrib['y1'])
            x2=float(line.attrib['x2']); y2=float(line.attrib['y2'])
        except Exception:
            continue
        if abs(x1-cx) <= tol and abs(y1-cy) <= tol:
            ports.append(v.dir_idx_from_vector(x2-x1, y2-y1))
    return ports


def extract_state_cells_from_group(group, radius_hint=None, include_blocked=False):
    """Return visible cells as list of {cx,cy,typ,state} from polygons in group."""
    cells=[]
    for poly in group.xpath('./*[local-name()="polygon"]'):
        cx,cy = polygon_centroid(poly)
        typ = fill_to_type(poly.attrib.get('fill'))
        if typ is None:
            continue
        if typ == 'blocked' and not include_blocked:
            continue
        if radius_hint is not None:
            rad = polygon_radius(poly, cx, cy)
            if abs(rad-radius_hint) > max(1.5, radius_hint*0.25):
                continue
        ports = line_ports_for_center(group, cx, cy)
        st = state_from_type_and_ports(typ, ports)
        cells.append({'cx':cx, 'cy':cy, 'type':typ, 'state':st, 'ports':ports})
    return cells


def main_xy_to_axial(x,y):
    r = round((y - MAIN_ORIGIN_Y) / MAIN_DY)
    q = round((x - MAIN_ORIGIN_X) / MAIN_DX - r/2.0)
    ex = MAIN_ORIGIN_X + MAIN_DX*(q + r/2.0)
    ey = MAIN_ORIGIN_Y + MAIN_DY*r
    err = math.hypot(x-ex, y-ey)
    return (q,r), err


def extract_main_state(root):
    group = root.xpath(f'//*[local-name()="svg" and @id="{MAIN_GROUP_ID}"]')[0]
    cells = extract_state_cells_from_group(group, radius_hint=MAIN_R, include_blocked=False)
    state = {}
    geom=[]
    errs=[]
    for c in cells:
        coord, err = main_xy_to_axial(c['cx'], c['cy'])
        errs.append(err)
        if err > 0.12:
            raise RuntimeError(f'main cell center does not map cleanly to axial coord: {c} -> {coord}, err={err}')
        if coord in state:
            raise RuntimeError(f'duplicate main cell at {coord}: {state[coord]} vs {c["state"]}')
        state[coord] = c['state']
        geom.append({'coord': list(coord), 'state': c['state'], 'cx': round(c['cx'],3), 'cy': round(c['cy'],3), 'ports': sorted(c['ports'])})
    return state, geom, {'count': len(cells), 'max_center_error': max(errs) if errs else None, 'mean_center_error': sum(errs)/len(errs) if errs else None}


def extract_p7_templates(root):
    templates=[]
    for i in range(15):
        gid=f'fix0_p7_rep_{i:02d}'
        groups = root.xpath(f'//*[local-name()="g" and @id="{gid}"]')
        if not groups:
            raise RuntimeError(f'missing P7 group {gid}')
        group = groups[0]
        cells = extract_state_cells_from_group(group, radius_hint=None, include_blocked=False)
        # First polygon in the group is the center by construction; use its centroid.
        first_poly = group.xpath('./*[local-name()="polygon"]')[0]
        ccx, ccy = polygon_centroid(first_poly)
        center_cell = min(cells, key=lambda c: math.hypot(c['cx']-ccx, c['cy']-ccy))
        center_state = center_cell['state']
        slots = [None]*6
        slot_geom = [None]*6
        for c in cells:
            if c is center_cell:
                continue
            dx = c['cx'] - ccx
            dy = c['cy'] - ccy
            dist = math.hypot(dx,dy)
            if abs(dist - P7_SPACING) > 1.2:
                # Should not happen for clean P7 icons.
                continue
            d = v.dir_idx_from_vector(dx, dy)
            if slots[d] is not None:
                raise RuntimeError(f'duplicate P7 slot {d} in {gid}')
            slots[d] = c['state']
            slot_geom[d] = {'cx': round(c['cx'],3), 'cy': round(c['cy'],3), 'state': c['state']}
        if any(s is None for s in slots):
            raise RuntimeError(f'incomplete P7 slots in {gid}: {slots}')
        templates.append({'rep_index': i, 'center': center_state, 'slots': slots, 'center_xy': [round(ccx,3), round(ccy,3)], 'slot_geom': slot_geom})
    return templates


def extract_matrix_status(root):
    mat = root.xpath(f'//*[local-name()="svg" and @id="{MATRIX_ID}"]')[0]
    status = {}
    pads=[]
    rect_details=[]
    for rect in mat.xpath('./*[local-name()="rect"]'):
        try:
            x=float(rect.attrib.get('x','nan')); y=float(rect.attrib.get('y','nan'))
            w=float(rect.attrib.get('width','nan')); h=float(rect.attrib.get('height','nan'))
        except Exception:
            continue
        fill=norm_hex_color(rect.attrib.get('fill'))
        # Only matrix cells live in this grid window and are small square-ish rects.
        if not (GRID_MIN_X <= x <= GRID_MAX_X and GRID_MIN_Y <= y <= GRID_MAX_Y and 4.0 <= w <= 7.2 and 4.0 <= h <= 7.2):
            continue
        col = round((x - GRID_START_X)/GRID_PITCH)
        row = round((y - GRID_START_Y)/GRID_PITCH)
        # pad rects are drawn slightly expanded; recenter before indexing if needed.
        if fill == COL_PAD and (abs(w-6.76)<0.2 or abs(h-6.76)<0.2):
            col = round(((x + (w-GRID_W)/2) - GRID_START_X)/GRID_PITCH)
            row = round(((y + (h-GRID_W)/2) - GRID_START_Y)/GRID_PITCH)
        if not (0 <= col < GRID_COLS and 0 <= row < GRID_ROWS):
            continue
        idx = row*GRID_COLS + col
        if fill == COL_ACCEPT:
            val='accept'
        elif fill == COL_REJECT:
            val='reject'
        elif fill == COL_PAD:
            val='pad'
        else:
            continue
        if idx in status and status[idx] != val:
            raise RuntimeError(f'matrix duplicate/conflict at {idx}: {status[idx]} vs {val}')
        status[idx] = val
        rect_details.append({'index': idx, 'status': val, 'x':x, 'y':y, 'fill':fill})
        if val == 'pad':
            pads.append(idx)
    return status, sorted(pads), sorted(rect_details, key=lambda d:d['index'])


def extract_accept_text_types(root):
    acc = root.xpath(f'//*[local-name()="svg" and @id="{ACCEPT_LIST_ID}"]')[0]
    types={}
    texts=[]
    for text_el in acc.xpath('.//*[local-name()="text"]'):
        txt=''.join(text_el.itertext()).strip()
        m = re.fullmatch(r'(\d{3})->([HD])', txt)
        if not m:
            continue
        idx=int(m.group(1)); typ=m.group(2)
        types[idx]=typ
        texts.append(txt)
    return types, texts


def compare_to_oracle(derived_accept, derived_reject):
    oracle_path = Path('/mnt/data/apex852_pdf_payload_v58.json')
    if not oracle_path.exists():
        return {'available': False}
    oracle = json.loads(oracle_path.read_text())
    da = {(r['matrix_index'], r['canonical_neighbor_key'], r['output']) for r in derived_accept}
    oa = {(r['matrix_index'], r['canonical_neighbor_key'], r['output']) for r in oracle['accept_rules']}
    dr = {(r['matrix_index'], r['canonical_neighbor_key']) for r in derived_reject}
    orj = {(r['matrix_index'], r['canonical_neighbor_key']) for r in oracle['reject_rules']}
    return {
        'available': True,
        'oracle_used_for_derivation': False,
        'accept_exact_match_count': len(da & oa),
        'accept_total_derived': len(da),
        'accept_total_oracle': len(oa),
        'accept_only_derived': sorted(list(da-oa))[:10],
        'accept_only_oracle': sorted(list(oa-da))[:10],
        'reject_exact_match_count': len(dr & orj),
        'reject_total_derived': len(dr),
        'reject_total_oracle': len(orj),
        'reject_only_derived': sorted(list(dr-orj))[:10],
        'reject_only_oracle': sorted(list(orj-dr))[:10],
    }


def main():
    parser = etree.XMLParser(recover=True, huge_tree=True, remove_blank_text=False)
    root = etree.fromstring(SVG_IN.read_bytes(), parser)

    main_state, main_geom, main_report = extract_main_state(root)
    p7_templates = extract_p7_templates(root)
    visible_matrix_status, pad_indices, matrix_rect_details = extract_matrix_status(root)
    accept_text_types, accept_texts = extract_accept_text_types(root)

    matrix_rows = v.build_matrix_from_p7(p7_templates)
    # Expand matrix status to every unique context; blank is implicit.
    status_by_index = {row['matrix_index']: 'blank' for row in matrix_rows}
    for idx, st in visible_matrix_status.items():
        if idx >= len(matrix_rows):
            # these should be pads only, beyond 536
            continue
        if st in ('accept','reject'):
            status_by_index[idx] = st
    accept_count = sum(1 for s in status_by_index.values() if s == 'accept')
    reject_count = sum(1 for s in status_by_index.values() if s == 'reject')
    blank_count = sum(1 for s in status_by_index.values() if s == 'blank')

    # Visible accept list must agree with matrix cells.
    accept_indices_from_matrix = {idx for idx,s in status_by_index.items() if s == 'accept'}
    accept_indices_from_text = set(accept_text_types)
    if accept_indices_from_matrix != accept_indices_from_text:
        raise RuntimeError({
            'accept_matrix_minus_text': sorted(accept_indices_from_matrix - accept_indices_from_text),
            'accept_text_minus_matrix': sorted(accept_indices_from_text - accept_indices_from_matrix),
        })

    forced = v.forced_replay_extract_outputs(matrix_rows, status_by_index, accept_text_types, main_state, max_steps=1000)
    if not forced.get('ok'):
        raise RuntimeError(f'forced replay failed: {forced}')
    outputs_by_key = {tuple(k.split('|')): out for k,out in forced['outputs_by_key'].items()}
    accept_rules, reject_rules = v.payload_rules_from_forced_outputs(matrix_rows, status_by_index, accept_text_types, outputs_by_key)

    acc_map = {tuple(r['canonical_neighbor_key'].split('|')): r['output'] for r in accept_rules}
    rej_set = {tuple(r['canonical_neighbor_key'].split('|')) for r in reject_rules}
    # Seed is visible main cells around blocked origin.
    axiom = {d: main_state.get(d) for d in v.DIRS_AXIAL}
    if any(x is None for x in axiom.values()):
        raise RuntimeError(f'missing visible seed neighbor around blocked origin: {axiom}')
    final_state, history, unknown = v.replay(acc_map, rej_set, axiom, max_steps=1000)
    cmp = v.compare_states(final_state, main_state)

    # Identify used rules for reduced-growth certificate.
    used_accept_keys = set(tuple(k.split('|')) for k in forced['used_accept_keys']) if 'used_accept_keys' in forced else set(outputs_by_key)
    # v44 forced result stores per-index usage too; handle both forms.
    used_accept_indices = set()
    used_reject_indices = set()
    key_to_idx = {row['canonical_neighbor_key']: row['matrix_index'] for row in matrix_rows}
    for k in used_accept_keys:
        used_accept_indices.add(key_to_idx.get(k))
    used_accept_indices.discard(None)
    # If no explicit used_accept_keys, derive from outputs_by_key.
    if not used_accept_indices:
        used_accept_indices = {key_to_idx[tuple(k.split('|'))] if isinstance(k,str) else key_to_idx[k] for k in outputs_by_key}
    # Recompute reject usage from final replay history/frontier is less direct; use forced diagnostics if present.
    # For reduction, all rejects are retained.
    reduced_accept = [r for r in accept_rules if r['matrix_index'] in used_accept_indices]
    reduced_payload = {
        'artifact': 'apex_v58_visible_svg_derived_reduced_growth_payload_v59',
        'source': str(SVG_IN),
        'derivation': 'visible SVG vector geometry only; no embedded payload used',
        'note': 'keeps only accept rules that actually fired in forced replay; keeps all rejects',
        'accept_rules': reduced_accept,
        'reject_rules': reject_rules,
        'seed_axiom': {f'{q},{r}': st for (q,r),st in sorted(axiom.items())},
    }
    red_acc_map = {tuple(r['canonical_neighbor_key'].split('|')): r['output'] for r in reduced_accept}
    red_final, red_history, red_unknown = v.replay(red_acc_map, rej_set, axiom, max_steps=1000)
    red_cmp = v.compare_states(red_final, main_state)

    derived_payload = {
        'artifact': 'apex_v58_visible_svg_derived_payload_v59',
        'source_svg': str(SVG_IN),
        'embedded_payload_used_for_derivation': False,
        'derivation_source': 'visible SVG vector geometry: main pattern, P7 thumbnails, matrix rectangles, accept-list text',
        'convention_read_from_page': {
            'main_origin_xy': [MAIN_ORIGIN_X, MAIN_ORIGIN_Y],
            'main_axial_basis': {'dx': MAIN_DX, 'dy': MAIN_DY},
            'mask_order': 'bit0=slot1/E, bit1=slot2/NE, bit2=slot3/NW, bit3=slot4/W, bit4=slot5/SW, bit5=slot6/SE',
            'matrix_order': 'row-major 18 columns, first 536 unique contexts; 4 black pad cells',
        },
        'counts': {
            'main_cells': len(main_state),
            'p7_templates': len(p7_templates),
            'unique_canonical_neighbor_contexts': len(matrix_rows),
            'accept': len(accept_rules),
            'reject': len(reject_rules),
            'blank': blank_count,
            'pad_to_540': len(pad_indices),
        },
        'seed_axiom': {f'{q},{r}': st for (q,r),st in sorted(axiom.items())},
        'p7_templates': [{'rep_index': t['rep_index'], 'center': t['center'], 'slots': t['slots']} for t in p7_templates],
        'matrix': {
            'status_by_index': {str(i): status_by_index[i] for i in sorted(status_by_index)},
            'pad_indices': pad_indices,
        },
        'accept_rules': accept_rules,
        'reject_rules': reject_rules,
        'verification': {
            'forced_replay': {k: forced[k] for k in forced if k not in {'outputs_by_key'}},
            'independent_replay': {
                'final_cells': len(final_state),
                'terminal_step': len(history)-1,
                'terminal_births': history[-1]['births'],
                'terminal_unknown_frontier': history[-1]['unknown_frontier'],
                'missing_vs_visible_main': len(cmp['missing']),
                'extra_vs_visible_main': len(cmp['extra']),
                'wrong_vs_visible_main': len(cmp['wrong']),
            },
            'reduced_growth_replay': {
                'accept_rules': len(reduced_accept),
                'reject_rules': len(reject_rules),
                'final_cells': len(red_final),
                'terminal_step': len(red_history)-1,
                'terminal_births': red_history[-1]['births'],
                'terminal_unknown_frontier': red_history[-1]['unknown_frontier'],
                'missing_vs_visible_main': len(red_cmp['missing']),
                'extra_vs_visible_main': len(red_cmp['extra']),
                'wrong_vs_visible_main': len(red_cmp['wrong']),
            },
        },
    }
    DERIVED_PAYLOAD_OUT.write_text(json.dumps(derived_payload, indent=2) + '\n')
    REDUCED_PAYLOAD_OUT.write_text(json.dumps(reduced_payload, indent=2) + '\n')
    STATE_OUT.write_text(json.dumps([{'q':q,'r':r,'state':st} for (q,r),st in sorted(main_state.items())], indent=2) + '\n')

    oracle = compare_to_oracle(accept_rules, reject_rules)
    report = {
        'artifact': 'apex_v58_visible_svg_extract_verify_report_v59',
        'source_svg': str(SVG_IN),
        'embedded_payload_used_for_derivation': False,
        'outputs': {
            'derived_payload': str(DERIVED_PAYLOAD_OUT),
            'reduced_growth_payload': str(REDUCED_PAYLOAD_OUT),
            'extracted_main_state': str(STATE_OUT),
        },
        'main_extraction': main_report,
        'p7_extraction': {
            'templates': len(p7_templates),
            'all_slots_present': all(len(t['slots']) == 6 and all(t['slots']) for t in p7_templates),
        },
        'matrix_extraction': {
            'colored_status_rects': len([d for d in matrix_rect_details if d['status'] in ('accept','reject')]),
            'accept': accept_count,
            'reject': reject_count,
            'blank': blank_count,
            'pad': len(pad_indices),
            'pad_indices': pad_indices,
            'accept_text_entries': len(accept_text_types),
            'accept_text_agrees_with_matrix': accept_indices_from_matrix == accept_indices_from_text,
        },
        'verification': derived_payload['verification'],
        'post_derivation_oracle_comparison': oracle,
        'sha256': {
            'derived_payload': hashlib.sha256(DERIVED_PAYLOAD_OUT.read_bytes()).hexdigest(),
            'reduced_growth_payload': hashlib.sha256(REDUCED_PAYLOAD_OUT.read_bytes()).hexdigest(),
            'extracted_main_state': hashlib.sha256(STATE_OUT.read_bytes()).hexdigest(),
        },
    }
    REPORT_OUT.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
