#!/usr/bin/env python3
import json, math, hashlib, copy, sys, importlib.util
from pathlib import Path
from lxml import etree
import cairosvg, fitz
sys.path.append('/mnt/data')
import visible_pdf_scrape_rederive_v44 as v
spec=importlib.util.spec_from_file_location('ex59','/mnt/data/apex_v58_visible_svg_extract_verify_v59.py')
ex59=importlib.util.module_from_spec(spec); spec.loader.exec_module(ex59)

NS='http://www.w3.org/2000/svg'
def E(tag): return f'{{{NS}}}{tag}'
def fmt(x):
    s=f'{x:.3f}'.rstrip('0').rstrip('.')
    return s if s else '0'
def clear(el):
    for ch in list(el): el.remove(ch)
def add_text(parent,x,y,txt,**attrs):
    el=etree.SubElement(parent,E('text')); el.attrib.update({'x':fmt(x),'y':fmt(y)})
    for k,vv in attrs.items(): el.attrib[k.replace('_','-')]=str(vv)
    el.text=txt; return el
def hex_points(cx,cy,R):
    pts=[(cx+R*math.sqrt(3)/2,cy+R/2),(cx,cy+R),(cx-R*math.sqrt(3)/2,cy+R/2),(cx-R*math.sqrt(3)/2,cy-R/2),(cx,cy-R),(cx+R*math.sqrt(3)/2,cy-R/2)]
    return ' '.join(f'{fmt(x)},{fmt(y)}' for x,y in pts)
def add_hex(parent,cx,cy,R,fill,stroke='#6f6960',sw='0.9'):
    return etree.SubElement(parent,E('polygon'),{'points':hex_points(cx,cy,R),'fill':fill,'stroke':stroke,'stroke-width':sw})

BASE_SVG=Path('/mnt/data/apex_and_chill_page13_v58_matrix_p7_restore.svg')
BASE_PDF=Path('/mnt/data/apex_and_chill_page13_v58_matrix_p7_restore.pdf')
SOURCE_RECORD=Path('/mnt/data/apex_v43/release09/data_image/apex_852_slowest_depth60.json')
STYLE_JSON=Path('/mnt/data/apex_v43/data/pseudocode_style_object_v40.json')
SVG_OUT=Path('/mnt/data/apex_and_chill_page13_v70_reduced_certificate.svg')
PDF_TMP=Path('/mnt/data/apex_and_chill_page13_v70_reduced_certificate_tmp.pdf')
PDF_OUT=Path('/mnt/data/apex_and_chill_page13_v70_reduced_certificate.pdf')
PAYLOAD_OUT=Path('/mnt/data/apex852_pdf_payload_v70_reduced_certificate.json')
REPORT_OUT=Path('/mnt/data/apex_and_chill_page13_v70_reduced_certificate_report.json')

BLUE='#2b4fc4'; BLUE_DARK='#1f3b92'; MAGENTA='#c53aa5'; MAGENTA_DARK='#912a7a'; GREY_BG='#fbfaf7'; GREY_LINE='#d7d1c7'; GREY_BORDER='#b8b1a6'; GREY_TEXT='#817a71'; BLACK='#181513'; WHITE='#ffffff'
DIRS=v.DIRS_AXIAL

# Extract visible current main/P7 from v58 SVG: this is the frame to satisfy.
parser=etree.XMLParser(remove_blank_text=False)
root=etree.fromstring(BASE_SVG.read_bytes(),parser)
main_state, main_geom, main_stats = ex59.extract_main_state(root)
p7_templates = ex59.extract_p7_templates(root)

# New visual-frame canonicalization: rotation by k sends slot p->p+k and state index i->i+k.
def plus_state(st,k):
    if st=='*': return '*'
    typ,i=st.split('.'); return f'{typ}.{(int(i)+k)%6}'
def plus_inv_state(st,k):
    if st=='*': return '*'
    typ,i=st.split('.'); return f'{typ}.{(int(i)-k)%6}'
def plus_key(raw,k):
    out=['*']*6
    for p,st in enumerate(raw): out[(p+k)%6]=plus_state(st,k)
    return tuple(out)
def plus_canon(raw):
    cands=[plus_key(tuple(raw),k) for k in range(6)]
    best=min(cands); return best,cands.index(best)

def custom_replay(accept_map, reject_set, axiom, max_steps=1000):
    state=dict(axiom); blocked={(0,0)}; history=[]; unknown=[]
    for t in range(max_steps):
        births={}; rejc=0; unknown=[]
        for q,r in sorted(v.frontier(state, blocked)):
            raw=tuple(state.get((q+dq,r+dr),'*') for dq,dr in DIRS)
            key,k=plus_canon(raw)
            if key in accept_map:
                births[(q,r)] = plus_inv_state(accept_map[key], k)
            elif key in reject_set:
                rejc += 1
            else:
                unknown.append({'cell':[q,r], 'raw_key':list(raw), 'canonical_key':list(key), 'rotation_k':k})
        history.append({'t':t,'births':len(births),'placed':len(state)+len(births),'rejected_frontier':rejc,'unknown_frontier':len(unknown)})
        if not births:
            return state, history, unknown
        state.update(births)
    raise RuntimeError('custom_replay max_steps exceeded')

def reflect_label(st): return '*' if st=='*' else v.transform_state_label(st,0,-1)

# Build current matrix from visible P7s and masks using plus canonicalization.
matrix_rows=[]; seen=set()
for rep in p7_templates:
    for mask in range(64):
        raw=tuple(rep['slots'][b] if ((mask>>b)&1) else '*' for b in range(6))
        key,k=plus_canon(raw)
        if key in seen: continue
        seen.add(key)
        matrix_rows.append({
            'matrix_index':len(matrix_rows),
            'outer_index':rep['rep_index']*64+mask,
            'rep_index':rep['rep_index'],
            'mask':mask,
            'mask_bits_slot1_to_slot6': ''.join('1' if ((mask>>b)&1) else '0' for b in range(6)),
            'canonical_neighbor_key': key,
            'canonical_rotation_k': k,
        })
key_to_index={r['canonical_neighbor_key']:r['matrix_index'] for r in matrix_rows}

# Transform known-good source accept/reject *status orbits* into current visual frame.
source=json.loads(SOURCE_RECORD.read_text())
def transform_status_keys(old_key):
    keys=set()
    for k_old in range(6):
        raw_old=v.rotate_key(tuple(old_key),k_old)  # old/source canonicalization
        raw_new=tuple(reflect_label(st) for st in raw_old)
        key_new,k_new=plus_canon(raw_new)
        keys.add(key_new)
    return keys
accept_keys=set(); accept_type_by_key={}; source_accepts_by_key={}
for rec in source['output']:
    typ=rec['out'].split('.')[0]
    for nk in transform_status_keys(rec['key']):
        accept_keys.add(nk); accept_type_by_key[nk]=typ; source_accepts_by_key.setdefault(nk,[]).append(rec)
reject_keys=set()
for key in source['blank_keys']:
    reject_keys |= transform_status_keys(key)

overlap=accept_keys & reject_keys
missing_accept=accept_keys-set(key_to_index)
missing_reject=reject_keys-set(key_to_index)
assert len(matrix_rows)==536, len(matrix_rows)
assert not overlap and not missing_accept and not missing_reject

# Force used output orientations by stepping through visible main. Rejects wait; accepts grow.
axiom={d:main_state.get(d) for d in DIRS}
state=dict(axiom); blocked={(0,0)}; outputs={}; used_reject_keys=set(); history=[]; unknown=[]; conflicts=[]
for t in range(1000):
    births={}; unknown=[]; conflicts=[]; rejc=0; acc_events=0
    for q,r in sorted(v.frontier(state,blocked)):
        raw=tuple(state.get((q+dq,r+dr),'*') for dq,dr in DIRS)
        key,k=plus_canon(raw)
        if key in accept_keys:
            if (q,r) not in main_state:
                conflicts.append({'kind':'accept_outside_visible_main','cell':[q,r],'key':list(key),'rotation_k':k}); continue
            target=main_state[(q,r)]
            out_type=accept_type_by_key[key]
            if not target.startswith(out_type+'.'):
                conflicts.append({'kind':'accept_type_mismatch','cell':[q,r],'key':list(key),'target':target,'expected_type':out_type}); continue
            can_out=plus_state(target,k)
            old=outputs.get(key)
            if old is not None and old!=can_out:
                conflicts.append({'kind':'output_conflict','cell':[q,r],'key':list(key),'old':old,'new':can_out}); continue
            outputs[key]=can_out; births[(q,r)]=target; acc_events+=1
        elif key in reject_keys:
            used_reject_keys.add(key)
            rejc += 1
        else:
            unknown.append({'cell':[q,r],'raw_key':list(raw),'canonical_key':list(key),'rotation_k':k,'visible_target':main_state.get((q,r))})
    history.append({'t':t,'births':len(births),'placed':len(state)+len(births),'accept_events':acc_events,'rejected_frontier':rejc,'unknown_frontier':len(unknown),'conflicts':len(conflicts)})
    if unknown or conflicts: break
    if not births: break
    state.update(births)
verification=v.compare_states(state,main_state)
assert verification['exact'] and history[-1]['births']==0 and history[-1]['unknown_frontier']==0 and not conflicts

# Build reduced finite-certificate payload: only rules actually touched in the verified 852-cell replay.
reduced_accept_keys=set(outputs.keys())
reduced_reject_keys=set(used_reject_keys)
accept_rules=[]
for key in sorted(reduced_accept_keys, key=lambda k:key_to_index[k]):
    out=outputs[key]
    accept_rules.append({
        'matrix_index': key_to_index[key],
        'canonical_neighbor_key': '|'.join(key),
        'output': out,
        'output_type': out.split('.')[0],
        'used_in_growth': True,
    })
reject_rules=[{'matrix_index':key_to_index[k],'canonical_neighbor_key':'|'.join(k)} for k in sorted(reduced_reject_keys, key=lambda k:key_to_index[k])]
# Sanity replay using ONLY the reduced rules.
reduced_acc_map={tuple(r['canonical_neighbor_key'].split('|')): r['output'] for r in accept_rules}
reduced_rej_set={tuple(r['canonical_neighbor_key'].split('|')) for r in reject_rules}
reduced_state,reduced_history,reduced_unknown=custom_replay(reduced_acc_map,reduced_rej_set,axiom)
reduced_verification=v.compare_states(reduced_state,main_state)
assert reduced_verification['exact'] and reduced_history[-1]['births']==0 and reduced_history[-1]['unknown_frontier']==0
payload={
    'artifact':'apex852_pdf_payload_v70_reduced_finite_certificate',
    'source_rule_record':str(SOURCE_RECORD),
    'derivation':'known-good source accept/reject status orbits transformed into current visible frame, then reduced to rules actually touched by verified finite growth; current visible-frame canonicalization uses slot p->p+k and state index i->i+k',
    'mask_order':'mask string positions are visible slots 1..6 = E,NE,NW,W,SW,SE; e.g. 011000 keeps slots 2 and 3',
    'canonicalization':'visual-frame C6: rotate key by k with slot p -> p+k and state index i -> i+k; choose lexicographic minimum',
    'counts':{'accept':len(accept_rules),'reject':len(reject_rules),'blank':536-len(accept_rules)-len(reject_rules),'pad_to_540':4,'unique_canonical_neighbor_contexts':len(matrix_rows)},
    'seed_axiom':{f'{q},{r}':st for (q,r),st in sorted(axiom.items())},
    'p7_templates':p7_templates,
    'matrix_rows':[dict(r, canonical_neighbor_key='|'.join(r['canonical_neighbor_key'])) for r in matrix_rows],
    'accept_rules':accept_rules,
    'reject_rules':reject_rules,
    'verification':dict(reduced_verification, terminal_step=len(reduced_history)-1, terminal_births=reduced_history[-1]['births'], terminal_unknown_frontier=reduced_history[-1]['unknown_frontier'], used_accept_outputs=len(accept_rules), used_reject_rules=len(reject_rules)),
}
PAYLOAD_OUT.write_text(json.dumps(payload,indent=2)+'\n')
payload_sha=hashlib.sha256(PAYLOAD_OUT.read_bytes()).hexdigest()

# SVG update - preserve main/P7; only update matrix status/list/payload metadata.
mat=root.xpath('//*[local-name()="svg" and @id="combined_rule_matrix_center0_modrot_v36"]')[0]
acc_svg=root.xpath('//*[local-name()="svg" and @id="accept_rule_list_91_v36"]')[0]
p7_groups=[copy.deepcopy(g) for g in mat.xpath('.//*[local-name()="g" and starts-with(@id,"fix0_p7_rep_")]')]
clear(mat)
etree.SubElement(mat,E('rect'),{'x':'0','y':'0','width':'583','height':'245','fill':'#ffffff'})
etree.SubElement(mat,E('line'),{'x1':'162','y1':'8','x2':'162','y2':'237','stroke':'#d8d2c8','stroke-width':'0.8'})
etree.SubElement(mat,E('line'),{'x1':'450','y1':'8','x2':'450','y2':'237','stroke':'#d8d2c8','stroke-width':'0.8'})
# grid
left_x,top_y=16.92,4.0; box_w,box_h=128.16,213.6; cell_size=5.44; pitch=7.12; cols=18; rows=30; start_x=17.76; start_y=4.84
etree.SubElement(mat,E('rect'),{'x':fmt(left_x),'y':fmt(top_y),'width':fmt(box_w),'height':fmt(box_h),'fill':GREY_BG,'stroke':GREY_BORDER,'stroke-width':'0.8'})
for c in range(1,cols):
    x=start_x-0.84+c*pitch; etree.SubElement(mat,E('line'),{'x1':fmt(x),'y1':'4.0','x2':fmt(x),'y2':fmt(top_y+box_h),'stroke':GREY_LINE,'stroke-width':'0.54'})
for r in range(1,rows):
    y=start_y-0.84+r*pitch; etree.SubElement(mat,E('line'),{'x1':fmt(left_x),'y1':fmt(y),'x2':fmt(left_x+box_w),'y2':fmt(y),'stroke':GREY_LINE,'stroke-width':'0.54'})
status_by_index={i:'blank' for i in range(len(matrix_rows))}
for key in reduced_reject_keys: status_by_index[key_to_index[key]]='reject'
for key in reduced_accept_keys: status_by_index[key_to_index[key]]='accept'
for idx in range(540):
    x=start_x+(idx%cols)*pitch; y=start_y+(idx//cols)*pitch
    if idx>=len(matrix_rows):
        etree.SubElement(mat,E('rect'),{'x':fmt(x-0.66),'y':fmt(y-0.66),'width':'6.76','height':'6.76','fill':'#000000'}); continue
    status=status_by_index[idx]
    if status=='blank': continue
    etree.SubElement(mat,E('rect'),{'x':fmt(x),'y':fmt(y),'width':fmt(cell_size),'height':fmt(cell_size),'fill':BLUE if status=='accept' else MAGENTA})
# Legend
etree.SubElement(mat,E('rect'),{'x':'15','y':'224','width':'10','height':'10','fill':BLUE,'stroke':'#6e685f','stroke-width':'0.55'})
add_text(mat,31,232.6,'Accept',**{'font-family':'DejaVu Serif','font-size':'8.2','fill':BLACK})
add_text(mat,72,232.6,f'  ({len(accept_rules)})',**{'font-family':'DejaVu Serif','font-size':'8.2','fill':GREY_TEXT})
etree.SubElement(mat,E('rect'),{'x':'86','y':'224','width':'10','height':'10','fill':MAGENTA,'stroke':'#6e685f','stroke-width':'0.55'})
add_text(mat,102,232.6,'Reject',**{'font-family':'DejaVu Serif','font-size':'8.2','fill':BLACK})
add_text(mat,144,232.6,f'  ({len(reject_rules)})',**{'font-family':'DejaVu Serif','font-size':'8.2','fill':GREY_TEXT})
# P7 groups restored
for g in p7_groups: mat.append(g)
# right pane
cx,cy,R=516.5,78.0,15.0
neigh={0:(math.sqrt(3)*R,0),1:(math.sqrt(3)/2*R,-1.5*R),2:(-math.sqrt(3)/2*R,-1.5*R),3:(-math.sqrt(3)*R,0),4:(-math.sqrt(3)/2*R,1.5*R),5:(math.sqrt(3)/2*R,1.5*R)}
add_hex(mat,cx,cy,R,'#f7f6f2',stroke='#6f6960',sw='0.65')
for d in range(6):
    dx,dy=neigh[d]; add_hex(mat,cx+dx,cy+dy,R,WHITE,stroke='#6f6960',sw='0.65')
num_pos={0:(542.481,81.1),1:(529.49,58.6),2:(503.51,58.6),3:(490.519,81.1),4:(503.51,103.6),5:(529.49,103.6)}
for d,lab in enumerate(['1','2','3','4','5','6']):
    x,y=num_pos[d]; add_text(mat,x,y,lab,text_anchor='middle',**{'font-family':'DejaVu Serif','font-size':'8.6','fill':'#000000'})
add_text(mat,516.5,136,'Example',text_anchor='middle',**{'font-family':'DejaVu Serif','font-size':'10.2','fill':BLACK})
add_text(mat,516.5,149,'43 = 101011',text_anchor='middle',**{'font-family':'Courier Prime, Courier New, monospace','font-size':'9.2','fill':BLACK})
ex_cx,ex_cy,ex_R=516.5,188.0,10.0
ex_bits=[1,0,1,0,1,1]  # decimal 43, slots 1..6; note 011000 fixture is separate text convention
exoff={0:(math.sqrt(3)*ex_R,0),1:(math.sqrt(3)/2*ex_R,-1.5*ex_R),2:(-math.sqrt(3)/2*ex_R,-1.5*ex_R),3:(-math.sqrt(3)*ex_R,0),4:(-math.sqrt(3)/2*ex_R,1.5*ex_R),5:(math.sqrt(3)/2*ex_R,1.5*ex_R)}
add_hex(mat,ex_cx,ex_cy,ex_R,'#dddddd',stroke='#666666',sw='0.8')
for d,bit in enumerate(ex_bits):
    dx,dy=exoff[d]; add_hex(mat,ex_cx+dx,ex_cy+dy,ex_R,'#000000' if bit else '#ffffff',stroke='#666666',sw='0.8')
# accept list
clear(acc_svg)
for i,rule in enumerate(accept_rules):
    col,row=i%13,i//13; x=3.0+col*44.0; y=9.0+row*10.0
    fill=BLUE_DARK if rule['output_type']=='H' else MAGENTA_DARK
    add_text(acc_svg,x,y,f"{rule['matrix_index']:03d}->{rule['output_type']}",**{'font-family':'Courier Prime, Courier New, monospace','font-size':'7.0','fill':fill})
# metadata
metas=root.xpath('//*[local-name()="metadata"]')
if metas:
    try: meta=json.loads(metas[0].text)
    except Exception: meta={}
    meta.update({'variant':'v70_reduced_certificate','payload_embedded':PAYLOAD_OUT.name,'payload_sha256':payload_sha,'counts':payload['counts'],'changed_visual_region':'matrix reduced to rules used by finite certificate; P7/main preserved; legend spacing fixed','verification':payload['verification']})
    metas[0].text=json.dumps(meta,sort_keys=True)
SVG_OUT.write_bytes(etree.tostring(root,encoding='utf-8',xml_declaration=False))
# PDF convert + restore link/attach
cairosvg.svg2pdf(url=str(SVG_OUT),write_to=str(PDF_TMP))
base=fitz.open(BASE_PDF); out=fitz.open(PDF_TMP)
for pno in range(min(len(base),len(out))):
    for link in base[pno].get_links():
        if link.get('kind')==fitz.LINK_URI:
            out[pno].insert_link({'kind':fitz.LINK_URI,'from':link['from'],'uri':link['uri']})
out.embfile_add(PAYLOAD_OUT.name,PAYLOAD_OUT.read_bytes(),filename=PAYLOAD_OUT.name,ufilename=PAYLOAD_OUT.name,desc='v69 plus visual-frame payload')
out.embfile_add(STYLE_JSON.name,STYLE_JSON.read_bytes(),filename=STYLE_JSON.name,ufilename=STYLE_JSON.name,desc='pseudocode style object v40')
out.save(PDF_OUT); out.close(); base.close()
pdf=fitz.open(PDF_OUT)
# fixture check p7#6 one-based, mask 011000 displayed slot order => integer 6
fixture_raw=tuple(p7_templates[5]['slots'][b] if ((6>>b)&1) else '*' for b in range(6))
fixture_key,fixture_rot=plus_canon(fixture_raw)
fixture_index=key_to_index[fixture_key]
fixture_status=status_by_index[fixture_index]
report={'artifact':'v70_reduced_certificate','svg':str(SVG_OUT),'pdf':str(PDF_OUT),'payload':str(PAYLOAD_OUT),'counts':payload['counts'],'verification':payload['verification'],'fixture_p7_6_mask_011000':{'raw_key':list(fixture_raw),'canonical_key':list(fixture_key),'matrix_index':fixture_index,'status':fixture_status},'pdf_link_uris':[ln['uri'] for ln in pdf[0].get_links() if ln.get('kind')==fitz.LINK_URI],'embedded_files':[pdf.embfile_info(i)['filename'] for i in range(pdf.embfile_count())],'image_xobjects':len(pdf[0].get_images(full=True))}
REPORT_OUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
