#!/usr/bin/env python3
"""
Rebuild the final PDF from the final SVG plus explicit embedded JSON sidecars.
This does not recompute the SVG layout. It is a portable PDF assembly check:
SVG -> PDF, then attach the certificate JSON and style JSON, and restore the
pink YouTube link annotation.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import cairosvg, fitz

DEFAULT_LINK_RECT = fitz.Rect(258.75, 297.0, 304.5, 346.5)
DEFAULT_LINK_URI = "https://www.youtube.com/watch?v=z5_rz6x4m3s"

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--svg', type=Path, default=Path('../artifact/apex_and_chill_page13_v88_bottom_spacing.svg'))
    ap.add_argument('--payload', type=Path, default=Path('../certificate/apex852_pdf_payload_v88_reduced_certificate.json'))
    ap.add_argument('--style', type=Path, default=Path('pseudocode_style_object_v40.json'))
    ap.add_argument('--out', type=Path, default=Path('rebuilt_from_final_svg_v88.pdf'))
    ns = ap.parse_args()
    tmp = ns.out.with_suffix('.tmp.pdf')
    cairosvg.svg2pdf(url=str(ns.svg), write_to=str(tmp))
    doc = fitz.open(tmp)
    doc[0].insert_link({'kind': fitz.LINK_URI, 'from': DEFAULT_LINK_RECT, 'uri': DEFAULT_LINK_URI})
    doc.embfile_add(ns.payload.name, ns.payload.read_bytes(), filename=ns.payload.name, ufilename=ns.payload.name, desc='Apex 852 reduced finite certificate payload')
    doc.embfile_add(ns.style.name, ns.style.read_bytes(), filename=ns.style.name, ufilename=ns.style.name, desc='Pseudocode style object')
    doc.save(ns.out)
    doc.close()
    tmp.unlink(missing_ok=True)
    print(ns.out)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
